#!/usr/bin/env node
// configure-android.mjs — inyecta metadatos del build en el proyecto Android
// y descomprime el fuente web. Sin dependencias externas salvo adm-zip.
//
// Variables de entorno (las que falten se leen de build_config.json dentro del zip):
//   SOURCE_ZIP    ruta del zip fuente (obligatorio)
//   APP_NAME      nombre de la app
//   PACKAGE_NAME  applicationId (com.tu.app)
//   VERSION_NAME  ej. "1.0.0"
//   VERSION_CODE  entero positivo
//   PERMISSIONS   JSON array de ids (ej. '["CAMERA","RECORD_AUDIO"]')
//   START_URL     opcional: si se setea, escribe assets/nexa_config.json
//   ICON_PATH     opcional: ruta a un PNG alternativo (si no, se usa icon.png del zip)
//   ANDROID_TEMPLATE_DIR  opcional, por defecto ./android-template

import fs from "fs";
import path from "path";
import AdmZip from "adm-zip";

const ROOT = process.cwd();
const TEMPLATE_DIR = path.resolve(ROOT, process.env.ANDROID_TEMPLATE_DIR || "android-template");
const APP_DIR = path.join(TEMPLATE_DIR, "app");
const MAIN_DIR = path.join(APP_DIR, "src", "main");
const ASSETS_DIR = path.join(MAIN_DIR, "assets");
const WWW_DIR = path.join(ASSETS_DIR, "www");
const MANIFEST_PATH = path.join(MAIN_DIR, "AndroidManifest.xml");
const BUILD_GRADLE_PATH = path.join(APP_DIR, "build.gradle");
const STRINGS_PATH = path.join(MAIN_DIR, "res", "values", "strings.xml");

function fail(msg) {
  console.error("[configure-android] ERROR:", msg);
  process.exit(1);
}

function readJSON(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

function escapeXml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ── 1. Descomprimir fuente ────────────────────────────────────────────
const sourceZipPath = process.env.SOURCE_ZIP;
if (!sourceZipPath || !fs.existsSync(sourceZipPath)) {
  fail(`SOURCE_ZIP no encontrado: ${sourceZipPath}`);
}

const EXTRACT_DIR = path.join(ROOT, ".nexa-source");
fs.rmSync(EXTRACT_DIR, { recursive: true, force: true });
fs.mkdirSync(EXTRACT_DIR, { recursive: true });

let zip;
try {
  zip = new AdmZip(sourceZipPath);
  zip.extractAllTo(EXTRACT_DIR, true);
} catch (err) {
  fail(`No se pudo descomprimir SOURCE_ZIP: ${err.message}`);
}

// build_config.json (metadatos escritos por el backend) sirve de fallback.
const buildConfig = readJSON(path.join(EXTRACT_DIR, "build_config.json")) || {};

const cfg = {
  appName: process.env.APP_NAME || buildConfig.appName,
  packageName: process.env.PACKAGE_NAME || buildConfig.packageName,
  versionName: process.env.VERSION_NAME || buildConfig.versionName || "1.0.0",
  versionCode: parseInt(process.env.VERSION_CODE || buildConfig.versionCode || "1", 10),
  permissions: process.env.PERMISSIONS
    ? JSON.parse(process.env.PERMISSIONS)
    : Array.isArray(buildConfig.permissions)
      ? buildConfig.permissions
      : [],
  startUrl: process.env.START_URL || buildConfig.startUrl || null,
};

if (!cfg.appName) fail("APP_NAME no definido (ni en env ni en build_config.json)");
if (!cfg.packageName) fail("PACKAGE_NAME no definido");
if (!Number.isInteger(cfg.versionCode) || cfg.versionCode < 1) {
  fail("VERSION_CODE inválido");
}
console.log("[configure-android] app:", cfg.appName, "| paquete:", cfg.packageName,
  "| versión:", cfg.versionName, `(${cfg.versionCode})`);

// ── 2. Copiar contenido web a assets/www/ ─────────────────────────────
fs.mkdirSync(WWW_DIR, { recursive: true });
const wwwSrc = path.join(EXTRACT_DIR, "www");
if (fs.existsSync(wwwSrc) && fs.statSync(wwwSrc).isDirectory()) {
  copyDir(wwwSrc, WWW_DIR);
  console.log("[configure-android] contenido web copiado a assets/www/");
} else if (fs.existsSync(path.join(EXTRACT_DIR, "index.html"))) {
  // Zip sin estructura www/: copiar todo el contenido a www/.
  copyDir(EXTRACT_DIR, WWW_DIR, (name) =>
    name !== "build_config.json" && name !== "nexa_config.json" && name !== "icon.png");
  console.log("[configure-android] contenido web (raíz del zip) copiado a assets/www/");
} else {
  console.log("[configure-android] sin contenido web; se mantiene index.html por defecto");
}

// ── 3. nexa_config.json (startUrl) ────────────────────────────────────
const nexaConfigSrc = path.join(EXTRACT_DIR, "nexa_config.json");
if (cfg.startUrl) {
  fs.mkdirSync(ASSETS_DIR, { recursive: true });
  fs.writeFileSync(
    path.join(ASSETS_DIR, "nexa_config.json"),
    JSON.stringify({ startUrl: cfg.startUrl }, null, 2),
  );
  console.log("[configure-android] assets/nexa_config.json escrito con startUrl");
} else if (fs.existsSync(nexaConfigSrc)) {
  fs.mkdirSync(ASSETS_DIR, { recursive: true });
  fs.copyFileSync(nexaConfigSrc, path.join(ASSETS_DIR, "nexa_config.json"));
  console.log("[configure-android] assets/nexa_config.json copiado del zip");
}

// ── 4. Parchear strings.xml (app_name) ────────────────────────────────
let strings = fs.readFileSync(STRINGS_PATH, "utf8");
strings = strings.replace(
  /<string name="app_name">[\s\S]*?<\/string>/,
  `<string name="app_name">${escapeXml(cfg.appName)}</string>`,
);
fs.writeFileSync(STRINGS_PATH, strings);
console.log("[configure-android] app_name actualizado");

// ── 5. Parchear app/build.gradle (applicationId, versionName, versionCode) ─
let gradle = fs.readFileSync(BUILD_GRADLE_PATH, "utf8");
gradle = gradle.replace(
  /applicationId\s+"[^"]*"/,
  `applicationId "${cfg.packageName}"`,
);
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${cfg.versionCode}`);
gradle = gradle.replace(
  /versionName\s+"[^"]*"/,
  `versionName "${cfg.versionName}"`,
);
fs.writeFileSync(BUILD_GRADLE_PATH, gradle);
console.log("[configure-android] applicationId/version actualizados");

// ── 6. Insertar permisos en AndroidManifest.xml ───────────────────────
const ALWAYS_PRESENT = new Set(["INTERNET", "ACCESS_NETWORK_STATE"]);
const permissionIds = new Set();
for (const p of cfg.permissions) {
  const id = String(p).trim().toUpperCase();
  if (id && !ALWAYS_PRESENT.has(id)) permissionIds.add(id);
}
let manifest = fs.readFileSync(MANIFEST_PATH, "utf8");
const permissionLines = Array.from(permissionIds)
  .map((id) => `    <uses-permission android:name="android.permission.${id}" />`)
  .join("\n");
manifest = manifest.replace(
  /<!--\s*NEXA_PERMISSIONS_PLACEHOLDER[\s\S]*?-->/,
  permissionLines || "    <!-- (sin permisos adicionales) -->",
);
fs.writeFileSync(MANIFEST_PATH, manifest);
console.log(
  `[configure-android] permisos inyectados: ${
    permissionIds.size ? Array.from(permissionIds).join(", ") : "(ninguno adicional)"
  }`,
);

// ── 7. Icono personalizado ────────────────────────────────────────────
let iconBytes = null;
const iconInZip = path.join(EXTRACT_DIR, "icon.png");
if (fs.existsSync(iconInZip)) {
  iconBytes = fs.readFileSync(iconInZip);
} else if (process.env.ICON_PATH && fs.existsSync(process.env.ICON_PATH)) {
  iconBytes = fs.readFileSync(process.env.ICON_PATH);
}

if (iconBytes) {
  // Quitar iconos vectoriales/adaptativos para que el PNG gane.
  const toRemove = [
    path.join(MAIN_DIR, "res", "mipmap-anydpi-v26", "ic_launcher.xml"),
    path.join(MAIN_DIR, "res", "mipmap-anydpi-v26", "ic_launcher_round.xml"),
    path.join(MAIN_DIR, "res", "mipmap", "ic_launcher.xml"),
  ];
  for (const f of toRemove) {
    if (fs.existsSync(f)) {
      fs.unlinkSync(f);
      console.log("[configure-android] eliminado (icono vectorial):", path.relative(ROOT, f));
    }
  }
  // Escribir PNG en todas las densidades (Android escala; xxxhdpi basta, pero
  // escribimos las comunes para evitar warnings).
  const densities = ["mipmap-mdpi", "mipmap-hdpi", "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi"];
  for (const d of densities) {
    const dir = path.join(MAIN_DIR, "res", d);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, "ic_launcher.png"), iconBytes);
  }
  console.log("[configure-android] icono personalizado instalado");
} else {
  console.log("[configure-android] sin icono personalizado; se usa el predeterminado");
}

console.log("[configure-android] OK — proyecto Android configurado.");

// ── helpers ───────────────────────────────────────────────────────────
function copyDir(src, dest, filter) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (filter && !filter(entry.name)) continue;
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(s, d, filter);
    } else {
      fs.copyFileSync(s, d);
    }
  }
}
