#!/usr/bin/env bash
# setup-android.sh — Instala (una sola vez, idempotente) todo lo necesario para
# compilar APKs localmente con NEXA APK STUDIO: JDK 17 (Temurin), Android SDK
# (cmdline-tools + platform android-34 + build-tools 34.0.0 + platform-tools) y
# Gradle 8.7. Todo bajo ~/.nexa/. Al final actualiza .env del proyecto.
#
# Uso:  bash scripts/setup-android.sh
# Se puede correr varias veces: lo que ya está instalado se salta.
set -uo pipefail

NEXA_HOME="${NEXA_HOME:-$HOME/.nexa}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$PROJECT_DIR/.env"

JDK_DIR="$NEXA_HOME/jdk-17"
ANDROID_HOME="$NEXA_HOME/android-sdk"
GRADLE_DIR="$NEXA_HOME/gradle-8.7"
TMP_DIR="$NEXA_HOME/tmp"

mkdir -p "$NEXA_HOME" "$TMP_DIR"

log()  { printf '\033[1;36m[setup]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[aviso]\033[0m %s\n' "$*"; }
err()  { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; }

# ── OS / arquitectura ─────────────────────────────────────────────────
UNAME_S="$(uname -s)"
UNAME_M="$(uname -m)"
case "$UNAME_S" in
  Linux*)  OS="linux"; OS_GO="linux" ;;
  Darwin*) OS="mac";   OS_GO="mac" ;;
  MINGW*|CYGWIN*|MSYS*)
    err "Windows detectado. NEXA usa herramientas Unix: ejecuta este script dentro de WSL (Ubuntu)."
    err "  1) Instala WSL: wsl --install"
    err "  2) Abre Ubuntu, clona/copia el proyecto ahí y repite: bash scripts/setup-android.sh"
    exit 1
    ;;
  *) err "Sistema operativo no soportado: $UNAME_S (solo Linux y macOS)."; exit 1 ;;
esac

case "$UNAME_M" in
  x86_64|amd64) ARCH="x64" ;;
  arm64|aarch64) ARCH="aarch64" ;;
  *) err "Arquitectura no soportada: $UNAME_M"; exit 1 ;;
esac
log "OS=$OS  ARCH=$ARCH  destino=$NEXA_HOME"

# ── Utilidades ────────────────────────────────────────────────────────
download() { # url dest
  if [ -f "$2" ]; then log "ya descargado: $(basename "$2")"; return 0; fi
  log "descargando: $(basename "$1")"
  curl -fSL --retry 3 --retry-delay 2 -o "$2" "$1" || { err "falló la descarga: $1"; exit 1; }
}

extract_zip() { # zip dest_dir
  mkdir -p "$2"
  if command -v unzip >/dev/null 2>&1; then
    unzip -q -o "$1" -d "$2" || { err "falló unzip de $1"; exit 1; }
  elif command -v python3 >/dev/null 2>&1; then
    python3 -m zipfile -e "$1" "$2" || { err "falló extracción (python) de $1"; exit 1; }
  else
    err "Necesito 'unzip' o 'python3' para extraer archivos. Instala uno: sudo apt-get install -y unzip"
    exit 1
  fi
}

# upsert_env KEY VALUE: añade o reemplaza en .env
upsert_env() {
  local key="$1" val="$2"
  if [ ! -f "$ENV_FILE" ]; then touch "$ENV_FILE"; fi
  if grep -q "^${key}=" "$ENV_FILE"; then
    # Reemplaza valor (delimita con | para evitar conflictos con / en rutas).
    sed -i.bak "s|^${key}=.*|${key}=\"${val}\"|" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
  else
    printf '%s="%s"\n' "$key" "$val" >> "$ENV_FILE"
  fi
}

# ── 1. JDK 17 (Temurin / Adoptium) ────────────────────────────────────
if [ -x "$JDK_DIR/bin/java" ]; then
  log "JDK 17 ya instalado en $JDK_DIR"
else
  JDK_URL="https://api.adoptium.net/v3/binary/latest/17/ga/${OS}/${ARCH}/jdk/hotspot/normal/eclipse"
  JDK_TAR="$TMP_DIR/jdk17.tar.gz"
  download "$JDK_URL" "$JDK_TAR"
  log "instalando JDK 17..."
  rm -rf "$JDK_DIR" && mkdir -p "$JDK_DIR"
  tar xzf "$JDK_TAR" -C "$JDK_DIR" --strip-components=1 || { err "falló extracción del JDK"; exit 1; }
  "$JDK_DIR/bin/java" -version || { err "JDK instalado pero no ejecutable"; exit 1; }
  log "JDK 17 OK: $("$JDK_DIR/bin/java" -version 2>&1 | head -1)"
fi
export JAVA_HOME="$JDK_DIR"
export PATH="$JAVA_HOME/bin:$PATH"

# ── 2. Android SDK (cmdline-tools + componentes) ──────────────────────
CMDLINE_TOOLS_VER="11076708" # cmdline-tools 11.0 (2024)
CMDLINE_ZIP="$TMP_DIR/cmdline-tools-${OS}.zip"
SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"

if [ -x "$SDKMANAGER" ]; then
  log "cmdline-tools ya instalados en $ANDROID_HOME"
else
  CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-${OS}-${CMDLINE_TOOLS_VER}_latest.zip"
  download "$CMDLINE_URL" "$CMDLINE_ZIP"
  log "instalando Android cmdline-tools..."
  EXTRACT_DIR="$TMP_DIR/cmdline-extract"
  rm -rf "$EXTRACT_DIR" && mkdir -p "$EXTRACT_DIR"
  extract_zip "$CMDLINE_ZIP" "$EXTRACT_DIR"
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest"
  mv "$EXTRACT_DIR/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  chmod +x "$SDKMANAGER" || true
  log "cmdline-tools OK"
fi
export ANDROID_HOME ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

log "aceptando licencias del Android SDK..."
yes 2>/dev/null | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1 || true

log "instalando componentes: platform-tools, platforms;android-34, build-tools;34.0.0 ..."
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" \
  "platform-tools" "platforms;android-34" "build-tools;34.0.0" \
  || { err "falló la instalación de componentes del SDK"; exit 1; }
log "Android SDK OK en $ANDROID_HOME"

# ── 3. Gradle 8.7 ─────────────────────────────────────────────────────
if [ -x "$GRADLE_DIR/bin/gradle" ]; then
  log "Gradle 8.7 ya instalado en $GRADLE_DIR"
else
  GRADLE_URL="https://services.gradle.org/distributions/gradle-8.7-bin.zip"
  GRADLE_ZIP="$TMP_DIR/gradle-8.7-bin.zip"
  download "$GRADLE_URL" "$GRADLE_ZIP"
  log "instalando Gradle 8.7..."
  EXTRACT_DIR="$TMP_DIR/gradle-extract"
  rm -rf "$EXTRACT_DIR" && mkdir -p "$EXTRACT_DIR"
  extract_zip "$GRADLE_ZIP" "$EXTRACT_DIR"
  rm -rf "$GRADLE_DIR"
  mv "$EXTRACT_DIR/gradle-8.7" "$GRADLE_DIR"
  chmod +x "$GRADLE_DIR/bin/gradle" || true
  log "Gradle OK: $("$GRADLE_DIR/bin/gradle" --version 2>/dev/null | grep Gradle | head -1)"
fi
export GRADLE_HOME="$GRADLE_DIR"
export PATH="$GRADLE_HOME/bin:$PATH"

# ── 4. Actualizar .env del proyecto ───────────────────────────────────
upsert_env "BUILD_DRIVER" "local"
upsert_env "ANDROID_HOME" "$ANDROID_HOME"
upsert_env "JAVA_HOME" "$JAVA_HOME"
upsert_env "GRADLE_HOME" "$GRADLE_HOME"
log ".env actualizado: BUILD_DRIVER=local, ANDROID_HOME, JAVA_HOME, GRADLE_HOME"

# ── Resumen ───────────────────────────────────────────────────────────
cat <<EOF

══════════════════════════════════════════════════════════════════
  NEXA APK STUDIO — entorno local listo ✔
══════════════════════════════════════════════════════════════════
  JAVA_HOME    = $JAVA_HOME
  ANDROID_HOME = $ANDROID_HOME
  GRADLE_HOME  = $GRADLE_HOME
  BUILD_DRIVER = local  (escrito en $ENV_FILE)

  Siguientes pasos:
    1. Reinicia el servidor (npm run dev) para que lea las nuevas vars.
    2. Regístrate con email (no necesitas Google) y crea tu primer APK.
    3. La compilación ocurre en tu máquina; luego descargas el .apk.

  Para desinstalar: rm -rf ~/.nexa y quita las vars de .env.
══════════════════════════════════════════════════════════════════
EOF
