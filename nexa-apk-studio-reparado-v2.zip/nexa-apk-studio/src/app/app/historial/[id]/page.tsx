"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  Download,
  AlertTriangle,
  XCircle,
  RotateCcw,
  Package,
  Clock,
  CheckCircle2,
  Hammer,
  Info,
} from "lucide-react";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { StatusBadge } from "@/components/Badge";
import { LoadingScreen, Spinner } from "@/components/Spinner";
import { SectionHeader } from "@/components/SectionHeader";
import { api, formatBytes, formatDateEs } from "@/lib/client/api";
import { useToast } from "@/lib/client/hooks";
import { playSuccess, playError, playClick } from "@/lib/client/sound";
import { STATUS_LABEL, type BuildDetailDTO, type BuildStatus } from "@/lib/types";

const ACTIVE: BuildStatus[] = ["QUEUED", "PREPARING", "BUILDING"];

export default function BuildDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const toast = useToast();
  const id = params.id;

  const [build, setBuild] = useState<BuildDetailDTO | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const prevStatus = useRef<BuildStatus | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    try {
      const b = await api.get<BuildDetailDTO>(`/api/builds/${id}`);
      setBuild((prev) => {
        // Efecto de sonido en la transición a estado terminal
        if (prev && prev.status !== b.status) {
          if (b.status === "COMPLETED") playSuccess();
          else if (b.status === "ERROR") playError();
        }
        prevStatus.current = b.status;
        return b;
      });
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo cargar la compilación");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  // Polling cada 3s mientras el estado esté activo
  useEffect(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (build && ACTIVE.includes(build.status)) {
      timerRef.current = setInterval(() => void load(), 3000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [build?.status, load]);

  const handleCancel = async () => {
    if (!build) return;
    setCancelling(true);
    try {
      await api.post(`/api/builds/${build.id}/cancel`);
      toast.info("Compilación cancelada.");
      void load();
    } catch (e) {
      playError();
      toast.error(e instanceof Error ? e.message : "No se pudo cancelar");
    } finally {
      setCancelling(false);
    }
  };

  if (loading) return <LoadingScreen text="Cargando compilación…" />;
  if (error || !build) {
    return (
      <Card>
        <div className="empty-state">
          <div className="es-icon">
            <AlertTriangle size={26} />
          </div>
          <h3>No se encontró la compilación</h3>
          <p className="muted small" style={{ maxWidth: 380, margin: "0 auto 18px" }}>
            {error || "Puede que haya sido eliminada o no pertenezca a tu cuenta."}
          </p>
          <Button variant="primary" href="/app/historial" icon={<ArrowLeft size={15} />}>
            Volver al historial
          </Button>
        </div>
      </Card>
    );
  }

  const isActive = ACTIVE.includes(build.status);
  const canCancel = isActive;

  return (
    <div>
      <div style={{ marginBottom: 18 }}>
        <Button variant="ghost" size="sm" href="/app/historial" icon={<ArrowLeft size={15} />}>
          Volver al historial
        </Button>
      </div>

      {/* Cabecera del build */}
      <Card className="anim-in mb-2">
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", marginBottom: 8 }}>
              <h2 style={{ margin: 0, fontSize: "1.4rem" }}>{build.appName}</h2>
              <StatusBadge status={build.status} />
            </div>
            <div className="muted small mono">{build.packageName}</div>
            <div className="muted small mt-1">
              v{build.versionName} (code {build.versionCode}) · creado {formatDateEs(build.createdAt)}
              {build.apkSize ? ` · ${formatBytes(build.apkSize)}` : ""}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {build.status === "COMPLETED" && build.hasApk && (
              <a
                href={`/api/builds/${build.id}/download`}
                download={`${build.appName.replace(/\s+/g, "_")}_v${build.versionName}.apk`}
                onClick={() => playClick()}
                className="btn btn-primary"
                style={{ textDecoration: "none" }}
              >
                <Download size={16} />
                Descargar APK
              </a>
            )}
            {canCancel && (
              <Button variant="danger" onClick={handleCancel} loading={cancelling} icon={<XCircle size={16} />}>
                Cancelar
              </Button>
            )}
            {build.status === "ERROR" && (
              <Button variant="secondary" href="/app/crear" icon={<RotateCcw size={15} />}>
                Reintentar (nueva compilación)
              </Button>
            )}
          </div>
        </div>

        {isActive && (
          <div
            className="alert alert-info mt-2"
            style={{ display: "flex", alignItems: "center", gap: 10 }}
            role="status"
          >
            <Spinner />
            <span>
              {STATUS_LABEL[build.status]}… se actualiza automáticamente cada 3 segundos.
            </span>
          </div>
        )}

        {build.status === "ERROR" && (
          <div className="alert alert-error mt-2" role="alert">
            <AlertTriangle size={18} style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <b>La compilación falló.</b>
              {build.errorMessage ? (
                <>
                  <br />
                  <span className="mono small" style={{ opacity: 0.9 }}>
                    {build.errorMessage}
                  </span>
                </>
              ) : (
                <span> Revisa el timeline de eventos para más detalles.</span>
              )}
            </div>
          </div>
        )}
      </Card>

      <div className="grid-2">
        {/* Info del paquete */}
        <Card className="anim-in delay-1">
          <SectionHeader title="Información del paquete" />
          <dl style={{ margin: 0, display: "flex", flexDirection: "column", gap: 10, fontSize: "0.88rem" }}>
            <div className="flex justify-between gap-3">
              <dt className="muted"><Package size={13} style={{ display: "inline", marginRight: 6 }} />Tipo de contenido</dt>
              <dd style={{ margin: 0, fontWeight: 600 }}>{build.contentType.replace("_", " ")}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="muted"><Clock size={13} style={{ display: "inline", marginRight: 6 }} />Última actualización</dt>
              <dd style={{ margin: 0 }}>{formatDateEs(build.updatedAt)}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="muted"><CheckCircle2 size={13} style={{ display: "inline", marginRight: 6 }} />APK generado</dt>
              <dd style={{ margin: 0, fontWeight: 600 }}>{build.hasApk ? "Sí" : "No"}</dd>
            </div>
            <div>
              <dt className="muted" style={{ marginBottom: 6 }}><Info size={13} style={{ display: "inline", marginRight: 6 }} />Permisos ({build.permissions.length})</dt>
              <dd style={{ margin: 0, display: "flex", flexWrap: "wrap", gap: 6 }}>
                {build.permissions.map((p) => (
                  <span key={p} className="badge badge-neutral mono" style={{ fontSize: "0.68rem" }}>
                    {p}
                  </span>
                ))}
              </dd>
            </div>
          </dl>
        </Card>

        {/* Timeline */}
        <Card className="anim-in delay-2">
          <SectionHeader
            title="Línea de tiempo"
            subtitle={isActive ? "En curso…" : `${build.events.length} eventos`}
          />
          {build.events.length === 0 ? (
            <p className="muted small">Aún no hay eventos registrados.</p>
          ) : (
            <div className="timeline">
              {build.events.map((ev, i) => (
                <div key={i} className="tl-item">
                  <div className="tl-title">{STATUS_LABEL[ev.status] || ev.status}</div>
                  {ev.message && <div className="tl-msg">{ev.message}</div>}
                  <div className="tl-time">{formatDateEs(ev.createdAt)}</div>
                </div>
              ))}
              {isActive && (
                <div className="tl-item">
                  <div className="tl-title" style={{ color: "var(--text-dim)" }}>
                    <Hammer size={13} style={{ display: "inline", marginRight: 6 }} />
                    En progreso…
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
