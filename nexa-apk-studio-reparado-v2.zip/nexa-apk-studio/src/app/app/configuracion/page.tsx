"use client";

import { useState } from "react";
import { signOut } from "next-auth/react";
import { Moon, Sun, Bell, Volume2, Globe, LogOut, Check, AlertTriangle, Save } from "lucide-react";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { Toggle } from "@/components/Toggle";
import { SectionHeader } from "@/components/SectionHeader";
import { Badge } from "@/components/Badge";
import { useUserPreferences, useToast } from "@/lib/client/hooks";
import { playClick, playError, playSuccess } from "@/lib/client/sound";

const ACCENT_PRESETS = [
  { name: "Violeta", value: "#8b5cf6" },
  { name: "Azul", value: "#3b82f6" },
  { name: "Cian", value: "#06b6d4" },
  { name: "Esmeralda", value: "#10b981" },
  { name: "Rosa", value: "#ec4899" },
  { name: "Ámbar", value: "#f59e0b" },
];

export default function ConfiguracionPage() {
  const { preferences, user, update, updateName } = useUserPreferences();
  const toast = useToast();

  const [nameDraft, setNameDraft] = useState(user?.name || "");
  const [nameSaving, setNameSaving] = useState(false);
  const [nameError, setNameError] = useState<string | null>(null);
  const [loggingOut, setLoggingOut] = useState(false);

  const setTheme = async (theme: "dark" | "light") => {
    playClick();
    try {
      await update({ theme });
      toast.success(theme === "dark" ? "Tema oscuro activado" : "Tema claro activado");
    } catch (e) {
      playError();
      toast.error(e instanceof Error ? e.message : "No se pudo guardar el tema");
    }
  };

  const setAccent = async (accent: string) => {
    playClick();
    try {
      await update({ accent });
    } catch (e) {
      playError();
      toast.error(e instanceof Error ? e.message : "No se pudo guardar el color");
    }
  };

  const setToggle = async (key: "notifications" | "sound", value: boolean) => {
    try {
      await update({ [key]: value });
      toast.success(
        key === "sound"
          ? value ? "Sonidos activados" : "Sonidos silenciados"
          : value ? "Notificaciones activadas" : "Notificaciones desactivadas"
      );
    } catch (e) {
      playError();
      toast.error(e instanceof Error ? e.message : "No se pudo guardar");
    }
  };

  const saveName = async () => {
    const v = nameDraft.trim();
    if (!v) {
      setNameError("El nombre no puede estar vacío.");
      return;
    }
    setNameSaving(true);
    setNameError(null);
    try {
      await updateName(v);
      playSuccess();
      toast.success("Nombre actualizado");
    } catch (e) {
      playError();
      setNameError(e instanceof Error ? e.message : "No se pudo guardar el nombre");
    } finally {
      setNameSaving(false);
    }
  };

  const handleLogout = async () => {
    playClick();
    setLoggingOut(true);
    await signOut({ callbackUrl: "/" });
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Apariencia */}
      <Card className="anim-in">
        <SectionHeader title="Apariencia" subtitle="Tema y color de acento de la interfaz" />

        <div className="toggle-row">
          <div>
            <div className="tr-title">Tema oscuro</div>
            <div className="tr-desc">
              {preferences.theme === "dark" ? (
                <>
                  <Moon size={13} style={{ display: "inline", verticalAlign: -2, marginRight: 4 }} />
                  Interfaz oscura activada
                </>
              ) : (
                <>
                  <Sun size={13} style={{ display: "inline", verticalAlign: -2, marginRight: 4 }} />
                  Interfaz clara activada
                </>
              )}
            </div>
          </div>
          <Toggle
            checked={preferences.theme === "dark"}
            onChange={(v) => setTheme(v ? "dark" : "light")}
            ariaLabel="Cambiar tema"
          />
        </div>

        <div style={{ padding: "16px 0", borderBottom: "1px solid var(--border)" }}>
          <div className="label" style={{ marginBottom: 12 }}>Color de acento</div>
          <div className="accent-swatches">
            {ACCENT_PRESETS.map((p) => (
              <button
                key={p.value}
                type="button"
                className={`swatch ${preferences.accent.toLowerCase() === p.value.toLowerCase() ? "active" : ""}`}
                style={{ background: p.value }}
                title={p.name}
                aria-label={`Color ${p.name}`}
                onClick={() => setAccent(p.value)}
              >
                {preferences.accent.toLowerCase() === p.value.toLowerCase() && (
                  <Check size={14} color="#fff" style={{ position: "absolute", inset: 0, margin: "auto" }} />
                )}
              </button>
            ))}
            <label className="swatch-custom" title="Color personalizado" aria-label="Color personalizado">
              <input
                type="color"
                value={/^#[0-9a-fA-F]{6}$/.test(preferences.accent) ? preferences.accent : "#8b5cf6"}
                onChange={(e) => setAccent(e.target.value)}
              />
            </label>
            <span className="mono small faint" style={{ marginLeft: 6 }}>{preferences.accent}</span>
          </div>
        </div>

        <div className="toggle-row">
          <div>
            <div className="tr-title" style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <Globe size={15} /> Idioma
            </div>
            <div className="tr-desc">La interfaz está disponible únicamente en español por ahora.</div>
          </div>
          <Badge tone="neutral">Español</Badge>
        </div>
      </Card>

      {/* Perfil */}
      <Card className="anim-in delay-1">
        <SectionHeader title="Perfil" subtitle="Tu nombre público en NEXA" />
        <Input
          label="Nombre de usuario"
          value={nameDraft}
          onChange={(e) => setNameDraft(e.target.value)}
          placeholder="Tu nombre"
          error={nameError || undefined}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              void saveName();
            }
          }}
        />
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <Button size="sm" variant="primary" onClick={() => void saveName()} loading={nameSaving} icon={<Save size={14} />}>
            Guardar nombre
          </Button>
        </div>
      </Card>

      {/* Preferencias */}
      <Card className="anim-in delay-2">
        <SectionHeader title="Preferencias" subtitle="Notificaciones y sonidos" />
        <Toggle
          checked={preferences.notifications}
          onChange={(v) => void setToggle("notifications", v)}
          label="Notificaciones"
          description="Avisos cuando termine una compilación."
        />
        <Toggle
          checked={preferences.sound}
          onChange={(v) => void setToggle("sound", v)}
          label="Sonidos"
          description="Click, éxito y error sintetizados (Web Audio)."
        />
        <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
          <Button size="sm" variant="secondary" icon={<Volume2 size={14} />} onClick={() => { playClick(); playSuccess(); }}>
            Probar sonido
          </Button>
        </div>
      </Card>

      {/* Sesión */}
      <Card className="anim-in delay-3">
        <SectionHeader title="Sesión" subtitle="Acciones de cuenta" />
        {nameError && (
          <div className="alert alert-error mb-2" role="alert">
            <AlertTriangle size={16} />
            <span>{nameError}</span>
          </div>
        )}
        <Button variant="danger" onClick={() => void handleLogout()} loading={loggingOut} icon={<LogOut size={16} />}>
          Cerrar sesión
        </Button>
      </Card>
    </div>
  );
}
