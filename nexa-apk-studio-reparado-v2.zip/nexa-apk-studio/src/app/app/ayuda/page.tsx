"use client";

import { useEffect, useState } from "react";
import {
  ChevronDown,
  HelpCircle,
  CheckCircle2,
  AlertTriangle,
  Github,
  Server,
  FileArchive,
  ShieldCheck,
  Hammer,
} from "lucide-react";
import { Card } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { SectionHeader } from "@/components/SectionHeader";
import { LoadingScreen } from "@/components/Spinner";
import { api } from "@/lib/client/api";

interface PipelineStatus {
  configured: boolean;
  repository?: string;
}

const FAQS = [
  {
    q: "¿Cómo funciona la compilación?",
    a: "Sube tu contenido (URL, HTML o ZIP), NEXA lo empaqueta en un proyecto Android WebView y dispara un workflow de GitHub Actions. El runner descarga el fuente, configura la plantilla Gradle con tu nombre, paquete, versión y permisos, compila un APK debug firmado y lo devuelve a la plataforma. Todo sin instalar el SDK de Android en tu máquina.",
  },
  {
    q: "¿Por qué se necesita GitHub Actions?",
    a: "Compilar APK requiere el SDK de Android, JDK 17 y Gradle — decenas de GB y minutos de CPU. GitHub Actions ejecuta esto en la nube de forma gratuita y aislada. El backend solo dispara el workflow y recibe el resultado; tu APK nunca se genera en el servidor web.",
  },
  {
    q: "¿Qué límites de tamaño hay?",
    a: "Archivos HTML y ZIP hasta 50 MB. El icono de la app hasta 2 MB (PNG o JPG). Si tu web tiene muchos recursos, comprímelos antes de subir el ZIP. El APK resultante suele pesar entre 3 y 8 MB.",
  },
  {
    q: "¿Qué permisos se incluyen?",
    a: "INTERNET es obligatorio (el WebView lo necesita) y viene preseleccionado y bloqueado. El resto (cámara, micrófono, ubicación, almacenamiento, vibración, notificaciones…) son opcionales y solo se añaden al AndroidManifest si los marcas. Los permisos peligrosos se piden en tiempo de ejecución desde la web.",
  },
  {
    q: "El ZIP que subo, ¿qué estructura debe tener?",
    a: "Un archivo .zip que contenga un index.html en la raíz (no dentro de una carpeta). Todo el contenido se copia a assets/www del proyecto Android. Enlaces relativos funcionan; evita rutas absolutas a tu disco local.",
  },
  {
    q: "¿Puedo instalar el APK en cualquier Android?",
    a: "Sí, es un APK debug firmado, instalable en cualquier dispositivo con Android 7.0 (API 24) o superior. Solo tienes que permitir «Instalar apps de fuentes desconocidas» la primera vez. Para publicarlo en Google Play necesitarás firmarlo con tu propia clave de producción (próximamente en NEXA).",
  },
];

function FaqItem({ q, a, open, onToggle }: { q: string; a: string; open: boolean; onToggle: () => void }) {
  return (
    <div className="faq-item">
      <button type="button" className="faq-q" onClick={onToggle} aria-expanded={open}>
        <span>{q}</span>
        <ChevronDown size={16} style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 200ms", flexShrink: 0 }} />
      </button>
      {open && <div className="faq-a">{a}</div>}
    </div>
  );
}

export default function AyudaPage() {
  const [pipeline, setPipeline] = useState<PipelineStatus | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    api
      .get<PipelineStatus>("/api/pipeline/status")
      .then(setPipeline)
      .catch(() => setPipeline({ configured: false }));
  }, []);

  if (!pipeline) return <LoadingScreen text="Comprobando estado del sistema…" />;

  return (
    <div className="flex flex-col gap-4">
      {/* Estado del pipeline */}
      <Card className="anim-in">
        <SectionHeader title="Estado del pipeline de compilación" subtitle="GitHub Actions" />
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 14,
            padding: 16,
            borderRadius: "var(--radius-sm)",
            background: pipeline.configured ? "rgba(16,185,129,0.08)" : "rgba(245,158,11,0.08)",
            border: `1px solid ${pipeline.configured ? "rgba(16,185,129,0.3)" : "rgba(245,158,11,0.35)"}`,
            flexWrap: "wrap",
          }}
        >
          {pipeline.configured ? (
            <CheckCircle2 size={28} color="#34d399" style={{ flexShrink: 0 }} />
          ) : (
            <AlertTriangle size={28} color="#fbbf24" style={{ flexShrink: 0 }} />
          )}
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ fontWeight: 700, fontSize: "1rem", marginBottom: 2 }}>
              {pipeline.configured ? "Pipeline configurado y listo" : "Pipeline no configurado"}
            </div>
            <div className="muted small">
              {pipeline.configured
                ? `Repositorio: ${pipeline.repository || "configurado"}. Tus compilaciones se procesarán automáticamente.`
                : "Las compilaciones se crearán pero no se compilarán hasta configurar GitHub Actions en el servidor."}
            </div>
          </div>
          <Badge tone={pipeline.configured ? "success" : "warning"}>
            {pipeline.configured ? "Operativo" : "Pendiente"}
          </Badge>
        </div>

        {!pipeline.configured && (
          <div className="mt-2" style={{ fontSize: "0.86rem", lineHeight: 1.7 }}>
            <div style={{ fontWeight: 600, marginBottom: 8, display: "flex", alignItems: "center", gap: 8 }}>
              <Github size={16} /> Instrucciones para el administrador
            </div>
            <ol style={{ margin: 0, paddingLeft: 20, color: "var(--text-dim)" }}>
              <li>
                Crea un repositorio en GitHub con el contenido de <span className="mono-chip">android-template</span> y{" "}
                <span className="mono-chip">.github/workflows/build-apk.yml</span>.
              </li>
              <li>
                Genera un <span className="mono-chip">Personal Access Token</span> con permiso{" "}
                <span className="mono-chip">repo</span> y <span className="mono-chip">workflow</span>.
              </li>
              <li>
                Define en el servidor las variables de entorno{" "}
                <span className="mono-chip">GITHUB_TOKEN</span> y{" "}
                <span className="mono-chip">GITHUB_REPOSITORY=owner/repo</span>.
              </li>
              <li>
                Define también <span className="mono-chip">PUBLIC_BASE_URL</span> (URL pública de esta app) para que el
                runner descargue el fuente.
              </li>
              <li>Reinicia el servidor y vuelve a comprobar este estado.</li>
            </ol>
          </div>
        )}
      </Card>

      {/* FAQ */}
      <Card className="anim-in delay-1">
        <SectionHeader title="Preguntas frecuentes" subtitle="Lo que más preguntan nuestros creadores" />
        <div>
          {FAQS.map((f, i) => (
            <FaqItem
              key={i}
              q={f.q}
              a={f.a}
              open={openFaq === i}
              onToggle={() => setOpenFaq(openFaq === i ? null : i)}
            />
          ))}
        </div>
      </Card>

      {/* Referencia rápida */}
      <Card className="anim-in delay-2">
        <SectionHeader title="Referencia rápida" />
        <div className="grid-3">
          {[
            { Icon: Hammer, t: "Crear", d: "POST /api/builds con tus datos y fuente." },
            { Icon: Server, t: "Pipeline", d: "GET /api/pipeline/status muestra si está operativo." },
            { Icon: FileArchive, t: "Descarga", d: "GET /api/builds/:id/download cuando está COMPLETED." },
            { Icon: ShieldCheck, t: "Permisos", d: "INTERNET obligatorio; el resto opcional." },
            { Icon: HelpCircle, t: "Soporte", d: "Revisa el estado del pipeline antes de reportar fallos." },
            { Icon: Github, t: "Código", d: "El runner compila con Gradle en ubuntu-latest." },
          ].map(({ Icon, t, d }) => (
            <div key={t} style={{ padding: 14, border: "1px solid var(--border)", borderRadius: "var(--radius-sm)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, fontWeight: 600, fontSize: "0.88rem" }}>
                <Icon size={16} color="var(--accent)" /> {t}
              </div>
              <div className="faint small">{d}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
