"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Link2,
  FileCode2,
  FileArchive,
  Hammer,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { Input, Field } from "@/components/Input";
import { FileDropzone } from "@/components/FileDropzone";
import { HtmlEditor } from "@/components/HtmlEditor";
import { PermissionsSelector } from "@/components/PermissionsSelector";
import { IconUpload } from "@/components/IconUpload";
import { SectionHeader } from "@/components/SectionHeader";
import { api, normalizeUrl, looksLikeHtml } from "@/lib/client/api";
import { useToast } from "@/lib/client/hooks";
import { playError, playBuildStart } from "@/lib/client/sound";
import type { ContentType, BuildDTO } from "@/lib/types";

const TABS: { id: ContentType; label: string; Icon: typeof Link2 }[] = [
  { id: "URL", label: "URL", Icon: Link2 },
  { id: "HTML_PASTE", label: "Código HTML", Icon: FileCode2 },
  { id: "HTML_FILE", label: "Archivo HTML", Icon: FileCode2 },
  { id: "ZIP", label: "ZIP", Icon: FileArchive },
];

const PACKAGE_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;

interface CreateResponse {
  build: BuildDTO;
  pipelineConfigured: boolean;
  message?: string;
}

export default function CrearPage() {
  const router = useRouter();
  const toast = useToast();

  const [appName, setAppName] = useState("");
  const [packageName, setPackageName] = useState("");
  const [versionName, setVersionName] = useState("1.0.0");
  const [versionCode, setVersionCode] = useState("1");
  const [iconFile, setIconFile] = useState<File | null>(null);

  const [contentType, setContentType] = useState<ContentType>("URL");
  const [url, setUrl] = useState("");
  const [html, setHtml] = useState("");
  const [htmlFile, setHtmlFile] = useState<File | null>(null);
  const [zipFile, setZipFile] = useState<File | null>(null);

  const [permissions, setPermissions] = useState<string[]>(["INTERNET"]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [pipelineWarning, setPipelineWarning] = useState<string | null>(null);
  const [createdBuild, setCreatedBuild] = useState<BuildDTO | null>(null);

  const canSubmit = useMemo(() => {
    if (submitting) return false;
    if (!appName.trim() || !packageName.trim()) return false;
    if (contentType === "URL") return url.trim().length > 0;
    if (contentType === "HTML_PASTE") return html.trim().length > 0;
    if (contentType === "HTML_FILE") return !!htmlFile;
    if (contentType === "ZIP") return !!zipFile;
    return false;
  }, [submitting, appName, packageName, contentType, url, html, htmlFile, zipFile]);

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!appName.trim()) e.appName = "El nombre de la app es obligatorio.";
    if (!packageName.trim()) {
      e.packageName = "El nombre de paquete es obligatorio.";
    } else if (!PACKAGE_RE.test(packageName.trim())) {
      e.packageName =
        "Formato inválido. Usa algo como com.miapp.web (minúsculas, al menos dos partes separadas por punto).";
    }
    const vc = parseInt(versionCode, 10);
    if (!versionCode.trim() || isNaN(vc) || vc < 1) e.versionCode = "El código de versión debe ser un entero ≥ 1.";
    if (!versionName.trim()) e.versionName = "La versión es obligatoria (ej. 1.0.0).";

    if (contentType === "URL") {
      const u = url.trim();
      if (!u) e.url = "Introduce la URL de tu web.";
      else if (looksLikeHtml(u)) e.url = "Esto parece código HTML, no una URL. Usa la pestaña Código HTML.";
    } else if (contentType === "HTML_PASTE") {
      if (!html.trim()) e.html = "Pega tu código HTML.";
    } else if (contentType === "HTML_FILE") {
      if (!htmlFile) e.htmlFile = "Selecciona un archivo .html.";
    } else if (contentType === "ZIP") {
      if (!zipFile) e.zip = "Selecciona un archivo .zip.";
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setPipelineWarning(null);
    setCreatedBuild(null);
    if (!validate()) {
      playError();
      return;
    }

    setSubmitting(true);
    playBuildStart();
    try {
      const form = new FormData();
      form.append("appName", appName.trim());
      form.append("packageName", packageName.trim());
      form.append("versionName", versionName.trim() || "1.0.0");
      form.append("versionCode", String(parseInt(versionCode, 10) || 1));
      form.append("contentType", contentType);
      form.append("permissions", JSON.stringify(permissions));

      if (contentType === "URL") form.append("url", normalizeUrl(url));
      if (contentType === "HTML_PASTE") form.append("html", html);
      if (contentType === "HTML_FILE" && htmlFile) form.append("source", htmlFile);
      if (contentType === "ZIP" && zipFile) form.append("source", zipFile);
      if (iconFile) form.append("icon", iconFile);

      const res = await api.postMultipart<CreateResponse>("/api/builds", form);

      if (res.pipelineConfigured === false) {
        setCreatedBuild(res.build);
        setPipelineWarning(
          res.message ||
            "El pipeline de GitHub Actions no está configurado. Tu compilación se creó pero no se procesará hasta configurar GITHUB_TOKEN y GITHUB_REPOSITORY en el servidor."
        );
        toast.info("Compilación creada, pero el pipeline no está configurado.");
      } else {
        toast.success("Compilación iniciada. Redirigiendo…");
        router.push(`/app/historial/${res.build.id}`);
      }
    } catch (err) {
      playError();
      const msg = err instanceof Error ? err.message : "No se pudo crear la compilación.";
      toast.error(msg);
      setErrors({ submit: msg });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {pipelineWarning && (
        <div className="alert alert-warning mb-2 anim-in" role="alert">
          <AlertTriangle size={18} style={{ flexShrink: 0, marginTop: 2 }} />
          <div>
            <b>Pipeline no configurado.</b> Tu compilación se guardó pero no se compilará hasta que el
            administrador configure GitHub Actions (variables <span className="mono-chip">GITHUB_TOKEN</span> y{" "}
            <span className="mono-chip">GITHUB_REPOSITORY</span>). Consulta la página de Ayuda para ver el estado.
            <div className="mt-1" style={{ fontSize: "0.8rem", opacity: 0.9 }}>
              {pipelineWarning}
            </div>
            {createdBuild && (
              <div className="mt-1">
                <Button
                  size="sm"
                  variant="secondary"
                  href={`/app/historial/${createdBuild.id}`}
                  icon={<ArrowRight size={14} />}
                >
                  Ver compilación #{createdBuild.id.slice(0, 8)}
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {errors.submit && (
        <div className="alert alert-error mb-2" role="alert">
          <AlertTriangle size={16} />
          <span>{errors.submit}</span>
        </div>
      )}

      <Card className="anim-in mb-2">
        <SectionHeader title="Datos de la aplicación" subtitle="Identidad y versión de tu APK" />
        <div className="grid-2">
          <Input
            label="Nombre de la app"
            value={appName}
            onChange={(e) => setAppName(e.target.value)}
            placeholder="Mi App Genial"
            error={errors.appName}
            maxLength={50}
            required
          />
          <Input
            label="Nombre de paquete"
            value={packageName}
            onChange={(e) => setPackageName(e.target.value.toLowerCase())}
            placeholder="com.miapp.web"
            error={errors.packageName}
            hint="Identificador único. Ej: com.miapp.web"
            required
          />
          <Input
            label="Versión (versionName)"
            value={versionName}
            onChange={(e) => setVersionName(e.target.value)}
            placeholder="1.0.0"
            error={errors.versionName}
          />
          <Input
            label="Código de versión (versionCode)"
            type="number"
            min={1}
            value={versionCode}
            onChange={(e) => setVersionCode(e.target.value)}
            placeholder="1"
            error={errors.versionCode}
          />
        </div>

        <Field label="Icono de la aplicación (opcional)">
          <div style={{ display: "flex", alignItems: "flex-start", gap: 18 }}>
            <IconUpload file={iconFile} onChange={setIconFile} />
            <div className="muted small" style={{ paddingTop: 6, flex: 1 }}>
              Si no subes un icono se usará el icono por defecto de NEXA. Se generarán automáticamente
              todos los tamaños (mipmap hdpi, xhdpi, xxhdpi…).
            </div>
          </div>
        </Field>
      </Card>

      <Card className="anim-in delay-1 mb-2">
        <SectionHeader title="Contenido" subtitle="¿De dónde sale tu aplicación?" />
        <div className="tabs" role="tablist" style={{ marginBottom: 20 }}>
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={contentType === id}
              className={`tab ${contentType === id ? "active" : ""}`}
              onClick={() => setContentType(id)}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </div>

        {contentType === "URL" && (
          <Input
            label="URL de tu web"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://miapp.com o simplemente miapp.com"
            error={errors.url}
            hint="Acepta con o sin https:// — se normaliza automáticamente."
            icon={<Link2 size={16} />}
          />
        )}

        {contentType === "HTML_PASTE" && (
          <Field
            label="Código HTML"
            error={errors.html}
            hint="Pega tu HTML completo (incluyendo <!DOCTYPE html>). Se usará como index.html."
          >
            <HtmlEditor
              value={html}
              onChange={setHtml}
              placeholder="<!DOCTYPE html>&#10;<html>&#10;  <body>¡Hola desde NEXA!</body>&#10;</html>"
            />
          </Field>
        )}

        {contentType === "HTML_FILE" && (
          <Field label="Archivo HTML" error={errors.htmlFile} hint="Un único archivo .html (máx. 50 MB).">
            <FileDropzone
              accept=".html,.htm,text/html"
              maxSizeMB={50}
              file={htmlFile}
              onFile={setHtmlFile}
              title="Arrastra tu archivo .html"
            />
          </Field>
        )}

        {contentType === "ZIP" && (
          <Field
            label="Archivo ZIP con tu web"
            error={errors.zip}
            hint="Máx. 50 MB. Debe contener un index.html en la raíz del ZIP."
          >
            <FileDropzone
              accept=".zip,application/zip,application/x-zip-compressed"
              maxSizeMB={50}
              file={zipFile}
              onFile={setZipFile}
              title="Arrastra tu archivo .zip"
            />
          </Field>
        )}
      </Card>

      <Card className="anim-in delay-2 mb-2">
        <SectionHeader
          title="Permisos de Android"
          subtitle="INTERNET es obligatorio para el WebView y no se puede desactivar"
        />
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, color: "var(--text-dim)", fontSize: "0.82rem" }}>
          <ShieldCheck size={15} color="var(--accent)" />
          Solo se añadirán al manifiesto los permisos que marques.
        </div>
        <PermissionsSelector selected={permissions} onChange={setPermissions} />
      </Card>

      <div className="anim-in delay-3" style={{ display: "flex", justifyContent: "flex-end", gap: 12, flexWrap: "wrap" }}>
        <Button variant="ghost" href="/app">
          Cancelar
        </Button>
        <Button
          type="submit"
          variant="primary"
          size="lg"
          loading={submitting}
          disabled={!canSubmit}
          icon={<Hammer size={18} />}
        >
          {submitting ? "Generando…" : "Generar APK"}
        </Button>
      </div>

      {!canSubmit && !submitting && (
        <p className="faint" style={{ textAlign: "right", marginTop: 8 }}>
          Completa los campos obligatorios para generar tu APK.
        </p>
      )}
    </form>
  );
}
