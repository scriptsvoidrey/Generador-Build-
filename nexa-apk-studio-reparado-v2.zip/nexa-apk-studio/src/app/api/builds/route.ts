// GET /api/builds → lista de builds del usuario (-createdAt).
// POST /api/builds → crea un build (multipart/form-data), empaqueta el fuente
// en un zip y dispara GitHub Actions si está configurado. NUNCA inventa éxito.
import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { getCurrentUserId } from "@/lib/server/auth";
import { toBuildDTO } from "@/lib/server/dto";
import { createBuildFieldsSchema, parsePermissions } from "@/lib/server/validators";
import { badRequest, serverError, unauthorized, zodDetails } from "@/lib/server/http";
import {
  activeDriver,
  dispatchBuild,
  generateCallbackToken,
  normalizeUrl,
  packageSource,
} from "@/lib/server/build-engine";
import { MAX_ICON_BYTES, MAX_UPLOAD_BYTES, storage } from "@/lib/server/storage";
import { configuredRepository } from "@/lib/server/github";

export const runtime = "nodejs";\nexport const dynamic = "force-dynamic";\nexport const revalidate = 0;

function strField(value: FormDataEntryValue | null): string | undefined {
  if (typeof value === "string") return value;
  return undefined;
}

function fileField(value: FormDataEntryValue | null): File | null {
  if (value instanceof File) return value;
  return null;
}

export async function GET() {
  const userId = await getCurrentUserId();
  if (!userId) return unauthorized();
  try {
    const builds = await prisma.build.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ builds: builds.map(toBuildDTO) });
  } catch (err) {
    console.error("[builds GET] error:", err);
    return serverError();
  }
}

export async function POST(request: Request) {
  const userId = await getCurrentUserId();
  if (!userId) return unauthorized();

  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return badRequest("No se pudo leer el formulario (multipart/form-data esperado)");
  }

  const fields = {
    appName: strField(formData.get("appName")),
    packageName: strField(formData.get("packageName")),
    versionName: strField(formData.get("versionName")),
    versionCode: strField(formData.get("versionCode")),
    contentType: strField(formData.get("contentType")),
    url: strField(formData.get("url")),
    html: strField(formData.get("html")),
    permissions: strField(formData.get("permissions")) ?? "[]",
  };

  const parsed = createBuildFieldsSchema.safeParse(fields);
  if (!parsed.success) {
    return badRequest("Campos inválidos", zodDetails(parsed.error));
  }
  const f = parsed.data;

  // Validar permisos (JSON array de ids conocidos).
  let permissions: string[];
  try {
    permissions = parsePermissions(f.permissions);
  } catch (err) {
    return badRequest(err instanceof Error ? err.message : "permissions inválido");
  }

  const sourceFile = fileField(formData.get("source"));
  const iconFile = fileField(formData.get("icon"));

  // Reglas por contentType.
  let startUrl: string | undefined;
  let html: string | undefined;
  let sourceBuffer: Buffer | undefined;

  if (f.contentType === "URL") {
    if (!f.url) return badRequest("El campo url es obligatorio cuando contentType=URL");
    const norm = normalizeUrl(f.url);
    if (norm.looksLikeCode) {
      return badRequest(
        "El campo url parece código HTML, no una URL. Si quieres pegar HTML usa contentType=HTML_PASTE.",
      );
    }
    startUrl = norm.url;
  } else if (f.contentType === "HTML_PASTE") {
    if (!f.html || !f.html.trim()) {
      return badRequest("El campo html es obligatorio cuando contentType=HTML_PASTE");
    }
    html = f.html;
  } else if (f.contentType === "HTML_FILE" || f.contentType === "ZIP") {
    if (!sourceFile) {
      return badRequest(
        `Debes subir un archivo en el campo 'source' cuando contentType=${f.contentType}`,
      );
    }
    if (sourceFile.size > MAX_UPLOAD_BYTES) {
      return badRequest(
        `El archivo fuente excede el límite de ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)} MB`,
      );
    }
    const name = sourceFile.name.toLowerCase();
    if (f.contentType === "ZIP" && !name.endsWith(".zip") && sourceFile.type !== "application/zip" && sourceFile.type !== "application/x-zip-compressed") {
      return badRequest("El campo source debe ser un archivo .zip");
    }
    if (
      f.contentType === "HTML_FILE" &&
      !name.endsWith(".html") &&
      !name.endsWith(".htm") &&
      sourceFile.type !== "text/html"
    ) {
      return badRequest("El campo source debe ser un archivo .html");
    }
    sourceBuffer = Buffer.from(await sourceFile.arrayBuffer());
  }

  // Validar icono (opcional).
  let iconBuffer: Buffer | undefined;
  let iconPath: string | null = null;
  if (iconFile && iconFile.size > 0) {
    if (iconFile.size > MAX_ICON_BYTES) {
      return badRequest("El icono excede el límite de 2 MB");
    }
    const iname = iconFile.name.toLowerCase();
    const okType =
      iconFile.type === "image/png" ||
      iconFile.type === "image/jpeg" ||
      iname.endsWith(".png") ||
      iname.endsWith(".jpg") ||
      iname.endsWith(".jpeg");
    if (!okType) {
      return badRequest("El icono debe ser PNG o JPG");
    }
    iconBuffer = Buffer.from(await iconFile.arrayBuffer());
    iconPath = "icon.png"; // se incluye dentro del zip fuente
  }

  const versionName = f.versionName?.trim() || "1.0.0";
  const versionCode = f.versionCode ?? 1;

  // Empaquetar fuente en zip normalizado.
  let zipBuffer: Buffer;
  try {
    zipBuffer = await packageSource({
      contentType: f.contentType,
      appName: f.appName,
      packageName: f.packageName,
      versionName,
      versionCode,
      permissions,
      startUrl,
      html,
      fileBuffer: sourceBuffer,
      iconBuffer,
    });
  } catch (err) {
    return badRequest(err instanceof Error ? err.message : "No se pudo empaquetar el fuente");
  }

  const callbackToken = generateCallbackToken();

  try {
    // 1. Crear Build en QUEUED + evento.
    const build = await prisma.build.create({
      data: {
        userId,
        appName: f.appName,
        packageName: f.packageName,
        versionName,
        versionCode,
        contentType: f.contentType,
        permissions: JSON.stringify(permissions),
        iconPath,
        callbackToken,
        status: "QUEUED",
        sourceRef: "", // se rellena tras guardar el zip
        events: {
          create: { status: "QUEUED", message: "Build en cola de compilación" },
        },
      },
    });

    // 2. Guardar zip del fuente.
    const sourceRef = await storage.saveBuffer(`${build.id}.zip`, zipBuffer, "uploads");
    await prisma.build.update({ where: { id: build.id }, data: { sourceRef } });

    // 3. Disparar compilación según driver activo (local por defecto, o github).
    //    dispatchBuild NO inventa éxito: si el driver no está configurado
    //    devuelve pipelineConfigured=false con mensaje de instrucciones.
    const dispatch = await dispatchBuild({ id: build.id, callbackToken });
    const pipelineConfigured = dispatch.pipelineConfigured;
    const message = dispatch.message;
    if (dispatch.runId) {
      await prisma.build.update({
        where: { id: build.id },
        data: { githubRunId: dispatch.runId },
      });
    }
    if (dispatch.dispatchedEventMessage) {
      await prisma.buildEvent.create({
        data: { buildId: build.id, status: "QUEUED", message: dispatch.dispatchedEventMessage },
      });
    }

    const finalBuild = await prisma.build.findUnique({ where: { id: build.id } });
    const responseBody: {
      build: ReturnType<typeof toBuildDTO>;
      pipelineConfigured: boolean;
      driver: string;
      message?: string;
      repository?: string;
    } = {
      build: toBuildDTO(finalBuild!),
      pipelineConfigured,
      driver: activeDriver(),
    };
    if (message) responseBody.message = message;
    const repo = dispatch.repository ?? configuredRepository();
    if (repo && pipelineConfigured) responseBody.repository = repo;

    return NextResponse.json(responseBody, { status: 201 });
  } catch (err) {
    console.error("[builds POST] error:", err);
    return serverError();
  }
}
