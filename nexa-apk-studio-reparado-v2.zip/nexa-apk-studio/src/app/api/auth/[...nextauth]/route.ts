export const dynamic = "force-dynamic";\nexport const revalidate = 0;\n\nimport NextAuth from "next-auth";
import { authOptions } from "@/lib/server/auth";

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
