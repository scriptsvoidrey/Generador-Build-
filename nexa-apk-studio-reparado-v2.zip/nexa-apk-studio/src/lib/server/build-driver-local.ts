// Driver de compilación LOCAL: compila el APK en la misma máquina (Node)
// usando el proyecto android-template + Gradle + Android SDK. No requiere
// GitHub ni config externa. El driver GitHub (github.ts) y las rutas de
// callback (/source, /status, /apk) siguen intactos para despliegues serverless.
//
// Modelo: cola en memoria + worker async en serie. La ruta API solo encola
// y retorna inmediatamente; la compilación ocurre en background.
import { spawn, type ChildProcess, type SpawnOptions } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";
import AdmZip from "adm-zip";
import { prisma } from "./db";
import { storage } from "./storage";

const ACTIVE_STATUSES = ["QUEUED", "PREPARING", "BUILDING"];
const LOG_TAIL_BYTES = 2000;

const queue: string[] = [];
const queuedSet = new Set<string>();
let workerRunning = false;

/** Encola un build para compilación local. Retorna inmediatamente (no bloquea). */
export function enqueueLocalBuild(buildId: string): void {
  if (queuedSet.has(buildId)) return;
  queuedSet.add(buildId);
  queue.push(buildId);
  void pumpWorker();
}

async function pumpWorker(): Promise<void> {
  if (workerRunning) return;
  workerRunning = true;
  try {
    while (queue.length > 0) {
      const id = queue.shift()!;
      queuedSet.delete(id);
      try {
        await buildLocal(id);
      } catch (err) {
        console.error(`[local-driver] build ${id} lanzó excepción:`, err);
        try {
          await markError(id, err instanceof Error ? err.message : "Error interno del compilador local");
        } catch {
          /* mejor esfuerzo */
        }
      }
    }
  } finally {
    workerRunning = false;
    // Algo pudo encolarse mientras terminábamos.
    if (queue.length > 0) void pumpWorker();
  }
}

/** ¿Puede compilar localmente? Requiere ANDROID_HOME apuntando a un dir existente. */
export function isLocalConfigured(): boolean {
  const androidHome = process.env.ANDROID_HOME?.trim();
  if (!androidHome) return false;
  try {
    return fs.statSync(androidHome).isDirectory();
  } catch {
    return false;
  }
}

function resolveGradleBin(): string {
  const gh = process.env.GRADLE_HOME?.trim();
  if (gh) {
    const candidate = path.join(gh, "bin", os.platform() === "win32" ? "gradle.bat" : "gradle");
    if (fs.existsSync(candidate)) return candidate;
  }
  return "gradle"; // se resuelve desde PATH
}

async function markError(buildId: string, message: string): Promise<void> {
  await prisma.$transaction([
    prisma.build.update({
      where: { id: buildId },
      data: { status: "ERROR", errorMessage: message.slice(0, 4000) },
    }),
    prisma.buildEvent.create({
      data: { buildId, status: "ERROR", message: message.slice(0, 2000) },
    }),
  ]);
}

async function setStatus(
  buildId: string,
  status: string,
  message: string,
  extra?: { apkPath?: string; apkSize?: number; errorMessage?: string | null },
): Promise<void> {
  await prisma.$transaction([
    prisma.build.update({
      where: { id: buildId },
      data: { status, ...(extra ?? {}) },
    }),
    prisma.buildEvent.create({ data: { buildId, status, message } }),
  ]);
}

/**
 * Compila un build localmente de verdad. NO inventa éxito: si Gradle falla,
 * el build queda en ERROR con el tail del log.
 */
export async function buildLocal(buildId: string): Promise<void> {
  const build = await prisma.build.findUnique({ where: { id: buildId } });
  if (!build) return;
  // Si ya terminó (o lo cancelaron), no re-procesar.
  if (!ACTIVE_STATUSES.includes(build.status)) return;

  const tmpDir = path.join(os.tmpdir(), `nexa-${build.id}`);
  const logPath = path.join(tmpDir, "build.log");

  try {
    // ── a. PREPARING ─────────────────────────────────────────────────
    await setStatus(build.id, "PREPARING", "Preparando entorno de compilación local");

    // ── b. Copiar android-template al dir temporal (contenidos a la raíz) ─
    fs.rmSync(tmpDir, { recursive: true, force: true });
    fs.mkdirSync(tmpDir, { recursive: true });
    const templateSrc = path.join(process.cwd(), "android-template");
    if (!fs.existsSync(templateSrc)) {
      throw new Error("No se encontró android-template/ en el proyecto");
    }
    fs.cpSync(templateSrc, path.join(tmpDir, "android-template"), { recursive: true });
    const templateWorkDir = path.join(tmpDir, "android-template");

    // Resolver fuente: path local o descarga desde blob.
    const sourceZipPath = path.join(tmpDir, "source.zip");
    const ref = build.sourceRef;
    if (!ref) throw new Error("Build sin fuente asociada");
    if (/^https?:\/\//i.test(ref)) {
      const res = await fetch(ref);
      if (!res.ok) throw new Error(`No se pudo descargar el fuente (HTTP ${res.status})`);
      const buf = Buffer.from(await res.arrayBuffer());
      fs.writeFileSync(sourceZipPath, buf);
    } else {
      const abs = storage.getAbsolutePath(ref);
      if (!fs.existsSync(abs)) throw new Error("Archivo fuente no encontrado en almacenamiento");
      fs.copyFileSync(abs, sourceZipPath);
    }

    // Inspeccionar zip: nexa_config.json → START_URL; icon.png → ICON_PATH.
    let startUrl: string | undefined;
    let iconPathEnv: string | undefined;
    try {
      const zip = new AdmZip(sourceZipPath);
      const nexaEntry = zip.getEntry("nexa_config.json");
      if (nexaEntry && !nexaEntry.isDirectory) {
        try {
          const cfg = JSON.parse(nexaEntry.getData().toString("utf8"));
          if (cfg && typeof cfg.startUrl === "string" && cfg.startUrl) startUrl = cfg.startUrl;
        } catch {
          /* ignorar nexa_config corrupto */
        }
      }
      const iconEntry = zip.getEntry("icon.png");
      if (iconEntry && !iconEntry.isDirectory && build.iconPath) {
        const iconTmp = path.join(tmpDir, "uploaded-icon.png");
        fs.writeFileSync(iconTmp, iconEntry.getData());
        iconPathEnv = iconTmp;
      }
    } catch {
      /* zip ya validado por el backend; si falla la inspección se continúa */
    }

    const env: Record<string, string> = {
      ...process.env,
      APP_NAME: build.appName,
      PACKAGE_NAME: build.packageName,
      VERSION_NAME: build.versionName,
      VERSION_CODE: String(build.versionCode),
      PERMISSIONS: build.permissions || "[]", // ya es JSON string
      SOURCE_ZIP: sourceZipPath,
      ANDROID_HOME: process.env.ANDROID_HOME || "",
      ANDROID_SDK_ROOT: process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || "",
    };
    if (startUrl) env.START_URL = startUrl;
    if (iconPathEnv) env.ICON_PATH = iconPathEnv;

    // ── c. Ejecutar configure-android.mjs ─────────────────────────────
    const configureScript = path.join(process.cwd(), "scripts", "configure-android.mjs");
    if (!fs.existsSync(configureScript)) {
      throw new Error("No se encontró scripts/configure-android.mjs");
    }
    const configureCode = await runAndLog(
      process.execPath,
      [configureScript],
      tmpDir,
      env,
      logPath,
    );
    if (configureCode !== 0) {
      const tail = tailOf(logPath, LOG_TAIL_BYTES);
      await markError(build.id, `Falló la configuración del proyecto Android:\n${tail}`);
      return;
    }

    // ── d. BUILDING ───────────────────────────────────────────────────
    await setStatus(build.id, "BUILDING", "Compilando APK con Gradle (assembleDebug)");

    // ── e. gradle assembleDebug ───────────────────────────────────────
    const gradleBin = resolveGradleBin();
    const gradleCode = await runAndLog(
      gradleBin,
      ["assembleDebug", "--no-daemon"],
      templateWorkDir,
      env,
      logPath,
    );

    // ── f. Resultado ──────────────────────────────────────────────────
    if (gradleCode !== 0) {
      const tail = tailOf(logPath, LOG_TAIL_BYTES);
      await markError(build.id, `Falló la compilación de Gradle (exit ${gradleCode}):\n${tail}`);
      return;
    }

    const apkSrc = path.join(templateWorkDir, "app", "build", "outputs", "apk", "debug", "app-debug.apk");
    if (!fs.existsSync(apkSrc)) {
      await markError(build.id, "Gradle terminó bien pero no se generó app-debug.apk");
      return;
    }
    const apkBuffer = fs.readFileSync(apkSrc);
    const apkRef = await storage.saveBuffer(`${build.id}.apk`, apkBuffer, "apks");
    await setStatus(
      build.id,
      "COMPLETED",
      `APK compilado localmente (${(apkBuffer.length / 1024 / 1024).toFixed(2)} MB)`,
      { apkPath: apkRef, apkSize: apkBuffer.length, errorMessage: null },
    );
  } finally {
    // Limpieza best-effort del dir temporal.
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {
      /* ignorar */
    }
  }
}

/** Ejecuta un proceso, redirige stdout+stderr a logPath; retorna exit code. */
function runAndLog(
  cmd: string,
  args: string[],
  cwd: string,
  env: Record<string, string>,
  logPath: string,
): Promise<number> {
  return new Promise<number>((resolve, reject) => {
    const logStream = fs.createWriteStream(logPath, { flags: "a" });
    logStream.on("error", reject);
    const child: ChildProcess = spawn(cmd, args, {
      cwd,
      env: env as NodeJS.ProcessEnv,
      stdio: ["ignore", "pipe", "pipe"],
    } as SpawnOptions);
    let stderrEnded = false;
    let stdoutEnded = false;
    const maybeCloseLog = () => {
      if (stdoutEnded && stderrEnded) logStream.end();
    };
    if (child.stdout) {
      child.stdout.pipe(logStream, { end: false });
      child.stdout.on("end", () => {
        stdoutEnded = true;
        maybeCloseLog();
      });
    } else {
      stdoutEnded = true;
    }
    if (child.stderr) {
      child.stderr.pipe(logStream, { end: false });
      child.stderr.on("end", () => {
        stderrEnded = true;
        maybeCloseLog();
      });
    } else {
      stderrEnded = true;
    }
    child.on("error", (err: Error) => {
      logStream.end(() => reject(err));
    });
    child.on("close", (code: number | null) => {
      const exitCode = code ?? 1;
      if (logStream.writable) {
        logStream.end(() => resolve(exitCode));
      } else {
        resolve(exitCode);
      }
    });
  });
}

function tailOf(file: string, bytes: number): string {
  try {
    const stat = fs.statSync(file);
    const fd = fs.openSync(file, "r");
    const start = Math.max(0, stat.size - bytes);
    const buf = Buffer.alloc(Math.min(bytes, stat.size));
    fs.readSync(fd, buf, 0, buf.length, start);
    fs.closeSync(fd);
    return buf.toString("utf8");
  } catch {
    return "(sin log disponible)";
  }
}

// ── Recuperación best-effort al cargar el módulo: re-encola builds que
// quedaron activos (reinicio del proceso). Solo en driver local.
if (process.env.BUILD_DRIVER !== "github") {
  void (async () => {
    try {
      const stuck = await prisma.build.findMany({
        where: { status: { in: ACTIVE_STATUSES } },
        select: { id: true },
      });
      for (const b of stuck) enqueueLocalBuild(b.id);
    } catch (err) {
      console.warn("[local-driver] recuperación de builds activos falló:", err);
    }
  })();
}
