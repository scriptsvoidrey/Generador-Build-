// Motor de builds: normalización de URL, empaquetado del fuente en un zip
// normalizado y constantes de estado. NO simula compilaciones: el build real
// lo ejecuta GitHub Actions vía workflow_dispatch.
import crypto from "crypto";
import AdmZip from "adm-zip";
import type { ContentType } from "@/lib/types";

export const ACTIVE_STATUSES = ["QUEUED", "PREPARING", "BUILDING"] as const;

export function generateCallbackToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export interface NormalizedUrl {
  url: string;
  looksLikeCode: boolean;
}

/**
 * Normaliza una URL. Si el contenido parece código HTML (empieza por "<" o "<!")
 * se marca looksLikeCode=true para rechazarlo cuando contentType=URL.
 * Si no tiene protocolo, se prefija "https://".
 */
export function normalizeUrl(input: string): NormalizedUrl {
  const trimmed = input.trim();
  const looksLikeCode = trimmed.startsWith("<") || trimmed.startsWith("<!");
  if (looksLikeCode) return { url: trimmed, looksLikeCode: true };
  let url = trimmed;
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  return { url, looksLikeCode: false };
}

export interface PackageSourceInput {
  contentType: ContentType;
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  permissions: string[];
  startUrl?: string; // solo contentType=URL
  html?: string; // solo HTML_PASTE
  fileBuffer?: Buffer; // HTML_FILE (único .html) o ZIP
  iconBuffer?: Buffer; // opcional
}

/**
 * Empaqueta el fuente en un zip normalizado con estructura:
 *   build_config.json   (metadatos para configure-android.mjs)
 *   nexa_config.json    (solo URL: {startUrl})
 *   icon.png            (si se subió icono)
 *   www/...             (contenido web para HTML_PASTE/HTML_FILE/ZIP)
 */
export async function packageSource(input: PackageSourceInput): Promise<Buffer> {
  const zip = new AdmZip();

  const buildConfig = {
    appName: input.appName,
    packageName: input.packageName,
    versionName: input.versionName,
    versionCode: input.versionCode,
    permissions: input.permissions,
    startUrl: input.contentType === "URL" ? input.startUrl : undefined,
  };
  zip.addFile("build_config.json", Buffer.from(JSON.stringify(buildConfig, null, 2)));

  if (input.contentType === "URL") {
    if (!input.startUrl) throw new Error("URL de inicio faltante");
    zip.addFile("nexa_config.json", Buffer.from(JSON.stringify({ startUrl: input.startUrl })));
  } else if (input.contentType === "HTML_PASTE") {
    if (!input.html) throw new Error("Contenido HTML faltante");
    zip.addFile("www/index.html", Buffer.from(input.html, "utf8"));
  } else if (input.contentType === "HTML_FILE") {
    if (!input.fileBuffer) throw new Error("Archivo HTML faltante");
    zip.addFile("www/index.html", input.fileBuffer);
  } else if (input.contentType === "ZIP") {
    if (!input.fileBuffer) throw new Error("Archivo ZIP faltante");
    repackageZip(input.fileBuffer, zip);
  }

  if (input.iconBuffer) {
    zip.addFile("icon.png", input.iconBuffer);
  }

  return zip.toBuffer();
}

/** Valida un ZIP de usuario (debe contener index.html) y lo copia a www/ en el zip destino. */
function repackageZip(userZipBuffer: Buffer, destZip: AdmZip): void {
  let srcZip: AdmZip;
  try {
    srcZip = new AdmZip(userZipBuffer);
  } catch {
    throw new Error("El archivo no es un ZIP válido");
  }
  const entries = srcZip.getEntries();
  const indexEntry = entries.find(
    (e) => !e.isDirectory && /(^|\/)index\.html?$/i.test(e.entryName),
  );
  if (!indexEntry) {
    throw new Error(
      "El ZIP no contiene un archivo index.html en la raíz ni en ningún subdirectorio.",
    );
  }
  // Directorio base = el que contiene a index.html.
  let base = "";
  const slashIdx = indexEntry.entryName.lastIndexOf("/");
  if (slashIdx >= 0) base = indexEntry.entryName.slice(0, slashIdx + 1);

  let copied = 0;
  for (const e of entries) {
    if (e.isDirectory) continue;
    if (!e.entryName.startsWith(base)) continue;
    const rel = e.entryName.slice(base.length);
    if (!rel) continue;
    destZip.addFile("www/" + rel, e.getData());
    copied++;
  }
  if (copied === 0) {
    throw new Error("No se pudo extraer contenido del ZIP.");
  }
}

// ── Selección de driver de compilación ─────────────────────────────────
// BUILD_DRIVER=local (por defecto) compila en la misma máquina.
// BUILD_DRIVER=github usa GitHub Actions (requiere vars configuradas).
import { enqueueLocalBuild, isLocalConfigured } from "./build-driver-local";
import {
  configuredRepository,
  isPipelineConfigured,
  triggerDispatch,
} from "./github";

export type BuildDriver = "local" | "github";

export function activeDriver(): BuildDriver {
  // Vercel no puede compilar localmente: elegir GitHub automáticamente si sus
  // credenciales están presentes, incluso cuando BUILD_DRIVER fue omitido.
  if (process.env.BUILD_DRIVER === "github") return "github";
  if (process.env.BUILD_DRIVER === "local") return "local";
  if (process.env.VERCEL === "1" && process.env.GITHUB_TOKEN?.trim() &&
      process.env.GITHUB_REPOSITORY?.includes("/")) return "github";
  return "local";
}

export interface DispatchResult {
  pipelineConfigured: boolean;
  message?: string;
  repository?: string;
  runId?: number;
  dispatchedEventMessage?: string;
}

const GITHUB_NOT_CONFIGURED_MESSAGE =
  "El pipeline de compilación (GitHub Actions) no está configurado. " +
  "El build quedó en cola. Para compilar APKs reales configura GITHUB_TOKEN, " +
  "GITHUB_REPOSITORY y PUBLIC_BASE_URL (alcanzable desde internet), y sube el " +
  "workflow .github/workflows/build-apk.yml al repositorio builder. " +
  "Alternativa: usa BUILD_DRIVER=local y ejecuta bash scripts/setup-android.sh.";

const LOCAL_NOT_CONFIGURED_MESSAGE =
  "El compilador local no está listo. Ejecuta bash scripts/setup-android.sh una vez " +
  "para instalar JDK 17 + Android SDK + Gradle, luego reinicia el servidor. " +
  "El build quedó en cola.";

/**
 * Tras crear el Build, dispara la compilación según el driver activo.
 * - local: encola en el worker local (fuego y olvido); retorna de inmediato.
 * - github: dispara workflow_dispatch (mejor esfuerzo) y devuelve runId.
 * NO inventa éxito: si el driver no está configurado, pipelineConfigured=false.
 */
export async function dispatchBuild(build: {
  id: string;
  callbackToken: string;
}): Promise<DispatchResult> {
  if (activeDriver() === "github") {
    if (!isPipelineConfigured()) {
      return { pipelineConfigured: false, message: GITHUB_NOT_CONFIGURED_MESSAGE };
    }
    const publicBase = (process.env.PUBLIC_BASE_URL || process.env.NEXTAUTH_URL || "")
      .replace(/\/+$/, "");
    const sourceUrl = `${publicBase}/api/builds/${build.id}/source?token=${build.callbackToken}`;
    const result = await triggerDispatch({
      build_id: build.id,
      callback_token: build.callbackToken,
      source_url: sourceUrl,
    });
    if (result.dispatched) {
      return {
        pipelineConfigured: true,
        runId: result.runId,
        repository: configuredRepository(),
        dispatchedEventMessage: `Pipeline de GitHub Actions disparado${
          result.runId ? ` (run #${result.runId})` : ""
        }`,
      };
    }
    console.error("[dispatch] github dispatch falló:", result.error);
    return {
      pipelineConfigured: false,
      message:
        "El pipeline está configurado pero no se pudo disparar la compilación. " +
        "Revisa GITHUB_TOKEN (permisos repo+workflow), GITHUB_REPOSITORY y que el workflow exista en la rama. " +
        "El build quedó en cola.",
    };
  }

  // Driver local (por defecto).
  if (isLocalConfigured()) {
    enqueueLocalBuild(build.id); // no await: worker async en background
    return { pipelineConfigured: true };
  }
  return { pipelineConfigured: false, message: LOCAL_NOT_CONFIGURED_MESSAGE };
}
