// Acceso a datos de NEXA.
// - Si DATABASE_URL está configurado → usa Prisma (Postgres, datos persistentes).
// - Si NO está configurado → MODO DEMO en memoria. Funciona en Vercel con CERO
//   configuración: registro, login, invitado y creación de builds funcionan.
//   Los datos viven mientras la función esté "caliente"; se reinician en cada
//   cold start. Para persistencia real, añade DATABASE_URL (Neon/Vercel Postgres).
import { PrismaClient } from "@prisma/client";
import { randomUUID } from "crypto";

const USE_PRISMA = !!process.env.DATABASE_URL?.trim();
export const DEMO_MODE = !USE_PRISMA;

// ── Prisma (producción) ─────────────────────────────────────────────────────
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };
const prismaClient =
  globalForPrisma.prisma ??
  (USE_PRISMA
    ? new PrismaClient({
        log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
      })
    : null);
if (process.env.NODE_ENV !== "production" && prismaClient) {
  globalForPrisma.prisma = prismaClient;
}

// ── Modo demo en memoria ────────────────────────────────────────────────────
type UserRow = Record<string, unknown>;
type BuildRow = Record<string, unknown>;
type EventRow = Record<string, unknown>;

const users: UserRow[] = [];
const builds: BuildRow[] = [];
const buildEvents: EventRow[] = [];

const now = () => new Date();
const newId = () => randomUUID();

function matchWhere(row: Record<string, unknown>, where: Record<string, unknown>): boolean {
  for (const [k, v] of Object.entries(where)) {
    if (v && typeof v === "object" && "in" in (v as Record<string, unknown>)) {
      const list = (v as { in: unknown[] }).in;
      if (!list.includes(row[k])) return false;
    } else if (row[k] !== v) {
      return false;
    }
  }
  return true;
}

function applySelect<T>(row: T, select?: Record<string, boolean>): T {
  if (!select) return row;
  const out: Record<string, unknown> = {};
  for (const k of Object.keys(select)) {
    if (select[k]) out[k] = (row as Record<string, unknown>)[k];
  }
  return out as T;
}

function withEvents(build: BuildRow, include?: Record<string, boolean>): BuildRow {
  if (!include?.events) return build;
  const events = buildEvents
    .filter((e) => e.buildId === build.id)
    .sort((a, b) => (a.createdAt as Date).getTime() - (b.createdAt as Date).getTime());
  return { ...build, events };
}

function sortRows<T extends Record<string, unknown>>(rows: T[], orderBy?: Record<string, string>): T[] {
  if (!orderBy) return rows;
  const [[key, dir]] = Object.entries(orderBy);
  return [...rows].sort((a, b) => {
    const av = a[key] as string | number | Date;
    const bv = b[key] as string | number | Date;
    const cmp = av < bv ? -1 : av > bv ? 1 : 0;
    return dir === "desc" ? -cmp : cmp;
  });
}

function makeUserDelegate() {
  return {
    async findUnique(args: { where: Record<string, unknown>; select?: Record<string, boolean> }) {
      const row = users.find((u) => matchWhere(u, args.where)) ?? null;
      return row ? applySelect(row, args.select) : null;
    },
    async create(args: { data: Record<string, unknown> }) {
      const row: UserRow = {
        id: newId(),
        preferences: '{"theme":"dark","accent":"#8b5cf6","notifications":true,"language":"es","sound":true}',
        provider: "credentials",
        createdAt: now(),
        updatedAt: now(),
        ...args.data,
      };
      users.push(row);
      return row;
    },
    async update(args: { where: Record<string, unknown>; data: Record<string, unknown> }) {
      const idx = users.findIndex((u) => matchWhere(u, args.where));
      if (idx === -1) throw new Error("User not found");
      users[idx] = { ...users[idx], ...args.data, updatedAt: now() };
      return users[idx];
    },
  };
}

function makeBuildDelegate() {
  return {
    async findUnique(args: {
      where: Record<string, unknown>;
      include?: Record<string, boolean>;
      select?: Record<string, boolean>;
    }) {
      const row = builds.find((b) => matchWhere(b, args.where)) ?? null;
      if (!row) return null;
      return applySelect(withEvents(row, args.include), args.select);
    },
    async findMany(args: {
      where?: Record<string, unknown>;
      orderBy?: Record<string, string>;
      take?: number;
      select?: Record<string, boolean>;
    }) {
      let rows = args.where ? builds.filter((b) => matchWhere(b, args.where!)) : [...builds];
      rows = sortRows(rows, args.orderBy);
      if (args.take) rows = rows.slice(0, args.take);
      return rows.map((r) => applySelect(r, args.select));
    },
    async create(args: { data: Record<string, unknown> }) {
      const row: BuildRow = {
        id: newId(),
        versionName: "1.0.0",
        versionCode: 1,
        iconPath: null,
        permissions: "[]",
        status: "QUEUED",
        errorMessage: null,
        apkPath: null,
        apkSize: null,
        githubRunId: null,
        createdAt: now(),
        updatedAt: now(),
        ...args.data,
      };
      builds.push(row);
      return row;
    },
    async update(args: { where: Record<string, unknown>; data: Record<string, unknown> }) {
      const idx = builds.findIndex((b) => matchWhere(b, args.where));
      if (idx === -1) throw new Error("Build not found");
      builds[idx] = { ...builds[idx], ...args.data, updatedAt: now() };
      return builds[idx];
    },
    async count(args?: { where?: Record<string, unknown> }) {
      const rows = args?.where ? builds.filter((b) => matchWhere(b, args.where!)) : builds;
      return rows.length;
    },
  };
}

function makeBuildEventDelegate() {
  return {
    async create(args: { data: Record<string, unknown> }) {
      const row: EventRow = { id: newId(), createdAt: now(), ...args.data };
      buildEvents.push(row);
      return row;
    },
    async findMany(args: { where?: Record<string, unknown>; orderBy?: Record<string, string> }) {
      let rows = args?.where ? buildEvents.filter((e) => matchWhere(e, args.where!)) : [...buildEvents];
      rows = sortRows(rows, args?.orderBy);
      return rows;
    },
  };
}

const userDelegate = makeUserDelegate();
const buildDelegate = makeBuildDelegate();
const buildEventDelegate = makeBuildEventDelegate();

const mock = {
  user: userDelegate,
  build: buildDelegate,
  buildEvent: buildEventDelegate,
  async $transaction(arg: unknown[] | ((tx: typeof mock) => Promise<unknown>)) {
    if (Array.isArray(arg)) return Promise.all(arg as Promise<unknown>[]);
    return (arg as (tx: typeof mock) => Promise<unknown>)(mock);
  },
};

export const prisma = (USE_PRISMA ? prismaClient : mock) as PrismaClient;
