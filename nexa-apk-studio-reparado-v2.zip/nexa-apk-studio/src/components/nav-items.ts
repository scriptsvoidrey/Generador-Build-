import {
  Home,
  PackagePlus,
  History,
  Settings,
  UserCircle,
  HelpCircle,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  href: string;
  label: string;
  shortLabel: string;
  Icon: LucideIcon;
}

/** 6 secciones compartidas por Sidebar (md+) y BottomNav (móvil). */
export const NAV_ITEMS: NavItem[] = [
  { href: "/app", label: "Inicio", shortLabel: "Inicio", Icon: Home },
  { href: "/app/crear", label: "Crear APK", shortLabel: "Crear", Icon: PackagePlus },
  { href: "/app/historial", label: "Historial", shortLabel: "Historial", Icon: History },
  { href: "/app/configuracion", label: "Configuración", shortLabel: "Ajustes", Icon: Settings },
  { href: "/app/cuenta", label: "Mi cuenta", shortLabel: "Cuenta", Icon: UserCircle },
  { href: "/app/ayuda", label: "Ayuda", shortLabel: "Ayuda", Icon: HelpCircle },
];
