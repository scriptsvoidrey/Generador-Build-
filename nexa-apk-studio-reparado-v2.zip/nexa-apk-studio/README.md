# NEXA APK STUDIO

Plataforma web completa y funcional que convierte proyectos web (URL, HTML pegado, archivo HTML o ZIP) en **APK de Android reales**, descargables e instalables.

Stack: **Next.js 14 (App Router) + TypeScript + Prisma (SQLite por defecto) + NextAuth v4 (Google + email/contraseña)**. Compilación APK real con **Gradle + Android SDK**: por defecto en tu máquina (`BUILD_DRIVER=local`, instalas las herramientas con `bash scripts/setup-android.sh`); alternativamente vía **GitHub Actions** para despliegues serverless (Vercel). Interfaz en español, tema oscuro premium con glassmorphism, PWA instalable, sonidos sintetizados (Web Audio) con toggle.

> Regla de oro del proyecto: **nunca se simula una compilación ni se inventa un APK exitoso**. Si el driver activo no está configurado (falta Android SDK en local, o faltan las vars de GitHub), la compilación se crea en estado `En espera` y la interfaz muestra las instrucciones. El APK real solo aparece cuando Gradle lo compila de verdad (en local o en GitHub).

---

## 1. Requisitos

- Node.js 20+ (probado con 22)
- npm
- Para **compilaciones APK reales en local** (por defecto): ejecuta una vez `bash scripts/setup-android.sh` (instala JDK 17 + Android SDK + Gradle 8.7 bajo `~/.nexa/` y actualiza `.env`). No necesitas cuenta de GitHub ni Google OAuth. En Windows usa WSL.
- Alternativa **solo para Vercel/serverless** (donde no hay Android SDK ni disco persistente): `BUILD_DRIVER=github` con un repositorio "builder" (ver sección 5).

## 2. Instalación y ejecución local

```bash
npm install
cp .env.example .env          # edita NEXTAUTH_SECRET (openssl rand -base64 32)
bash scripts/setup-android.sh # (una sola vez) instala JDK17 + Android SDK + Gradle para compilar APKs en local
npm run db:push               # crea la base de datos SQLite (prisma/dev.db)
npm run dev                   # http://localhost:3000
```
Guía rápida de usuario: ver [GUIA_RAPIDA.md](./GUIA_RAPIDA.md).

Build de producción:

```bash
npm run build && npm start
```

## 3. Variables de entorno (`.env`)

| Variable | Descripción |
|---|---|
| `DATABASE_URL` | Por defecto `file:./dev.db` (SQLite). En producción: URL de Postgres (Vercel Postgres / Neon) y cambiar `provider` a `postgresql` en `prisma/schema.prisma`. |
| `NEXTAUTH_SECRET` | Secreto aleatorio (`openssl rand -base64 32`). **Obligatorio**. |
| `NEXTAUTH_URL` | URL pública de la app (ej. `https://nexa-tuusuario.vercel.app`). |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | OAuth de Google (opcional; si no se configuran, el botón de Google muestra un aviso). |
| `GITHUB_TOKEN` | Personal Access Token con permisos `repo` y `workflow` (para disparar compilaciones). |
| `GITHUB_REPOSITORY` | Repo builder con el workflow, ej. `tu-usuario/nexa-apk-builder`. |
| `GITHUB_WORKFLOW_ID` | Normalmente `build-apk.yml`. |
| `GITHUB_DEFAULT_BRANCH` | Rama del repo builder (normalmente `main`). |
| `BUILD_CALLBACK_SECRET` | Secreto compartido (`openssl rand -hex 32`). El runner lo usa para autenticar los callbacks al backend. |
| `PUBLIC_BASE_URL` | URL **alcanzable desde los runners de GitHub** (Vercel o túnel ngrok). `localhost` no funciona: GitHub no puede descargar el fuente desde tu máquina. |
| `STORAGE_DRIVER` | `local` (defecto) o `vercel-blob`. En Vercel serverless el disco es efímero: usa Blob. |
| `BLOB_READ_WRITE_TOKEN` | Token de Vercel Blob (si `STORAGE_DRIVER=vercel-blob`). |
| `MAX_UPLOAD_MB` | Límite de subida (defecto 50). |
| `BUILD_DRIVER` | `local` (defecto, compila en tu máquina tras `scripts/setup-android.sh`) o `github` (solo para Vercel/serverless). |
| `ANDROID_HOME` / `JAVA_HOME` / `GRADLE_HOME` | Las escribe `scripts/setup-android.sh`. Necesarias para el driver local. |

## 4. Despliegue en Vercel

1. Sube el proyecto a GitHub.
2. Importa en Vercel. Framework: Next.js.
3. Añade las variables de entorno (sección 3). Para producción usa `DATABASE_URL` de Postgres y `STORAGE_DRIVER=vercel-blob` (crea un store Blob en Vercel).
4. En **Settings → Functions**, región cercana a tus usuarios.
5. Despliega. La primera vez ejecuta `prisma db push` (o añade `prisma migrate deploy`) — el script `build` ya ejecuta `prisma generate`.
6. La app es una **PWA**: `manifest.json` + `sw.js` se sirven desde `/public`; es instalable en Android/desktop.

## 5. Cómo funcionan las compilaciones APK reales (pipeline)

Dos drivers, seleccionados con `BUILD_DRIVER` (defecto: `local`). El driver
GitHub y las rutas de callback (`/source`, `/status`, `/apk`) siguen intactos.

**Driver local (por defecto, sin GitHub):** el backend compila en la misma
máquina. Un worker async en memoria (`src/lib/server/build-driver-local.ts`)
procesa builds en serie sin bloquear la API: copia `android-template/` a un
directorio temporal, ejecuta `scripts/configure-android.mjs`, luego
`gradle assembleDebug`, y guarda el APK resultante en `storage/apks/`. Requiere
`ANDROID_HOME` (lo instala `scripts/setup-android.sh`); si no está, el build
queda en `En espera` con el aviso de ejecutar el setup. Al arrancar, recupera
best-effort los builds que quedaron activos.

**Driver GitHub (solo para Vercel/serverless, donde no cabe el Android SDK):**
el flujo es:

1. El usuario envía su proyecto (URL / HTML / archivo / ZIP). El backend lo empaqueta en un ZIP y crea un `Build` en estado `QUEUED` (`En espera`).
2. Si `GITHUB_TOKEN` y `GITHUB_REPOSITORY` están configurados, el backend dispara `workflow_dispatch` en el repo builder, pasando `build_id`, `callback_token` y `source_url`.
3. El runner de GitHub (`.github/workflows/build-apk.yml`):
   - instala JDK 17, Gradle 8.7 y Android SDK (android-34, build-tools 34.0.0);
   - descarga el fuente ZIP desde `PUBLIC_BASE_URL/api/builds/<id>/source?token=...`;
   - ejecuta `scripts/configure-android.mjs`: inyecta nombre de app, `applicationId`, versión, permisos en el `AndroidManifest`, descomprime el contenido web en `assets/www/` (o escribe `nexa_config.json` con la URL de inicio), instala el icono personalizado;
   - reporta `PREPARANDO` → `COMPILANDO` al backend vía callbacks autenticados con token;
   - ejecuta `gradle assembleDebug` (APK debug firmado, instalable directamente en Android);
   - en éxito: reporta `COMPLETADO` y sube el APK por POST a `/api/builds/<id>/apk`; en fallo: reporta `ERROR` con el mensaje truncado del log;
   - además sube el APK como artifact de GitHub como respaldo.
4. El frontend hace polling cada 3 s en la página de detalle y muestra el estado (`En espera / Preparando / Compilando / Completado / Error`). Cuando está `Completado`, el botón **Descargar APK** sirve el binario real.

### Configurar el repo builder (una sola vez)

1. Crea un repo (público o privado), ej. `nexa-apk-builder`.
2. Copia a su raíz las carpetas `android-template/`, `scripts/` y `.github/workflows/build-apk.yml` de este proyecto.
3. En el repo builder: **Settings → Secrets and variables → Actions → Variables**, crea `PUBLIC_BASE_URL` con la URL de tu despliegue.
4. En el backend (Vercel), define `GITHUB_TOKEN` (PAT con `repo`+`workflow`), `GITHUB_REPOSITORY=tu-usuario/nexa-apk-builder`, `BUILD_CALLBACK_SECRET`.
5. La página **Ayuda** de la app indica si el pipeline está configurado (`GET /api/pipeline/status`).

> Limitación honesta: en local (`localhost`) GitHub no puede descargar el fuente. Usa `ngrok http 3000` y pon esa URL en `PUBLIC_BASE_URL`, o despliega en Vercel. Hasta entonces las compilaciones quedan en `En espera` con instrucciones visibles — no se miente con éxitos falsos.

## 6. Estructura del proyecto

```
prisma/schema.prisma          Modelos User / Build / BuildEvent (SQLite por defecto)
src/app/api/                  12 rutas API (auth, user, builds, pipeline)
src/lib/server/               db, auth (NextAuth), storage, github, build-engine, build-driver-local, validators, dto
src/middleware.ts             Protección de rutas /app/* y /api/*
src/app/layout.tsx            Root layout (fuentes, Providers, PWA)
src/app/(welcome)/page.tsx    Pantalla de bienvenida pública
src/app/login, /register      Autenticación
src/app/app/                  Área protegida: dashboard, crear, historial[/id],
                              configuración, cuenta, ayuda
src/components/               Sidebar (desktop), BottomNav (móvil), UI kit
src/lib/client/               api.ts, sound.ts (Web Audio), hooks
src/styles/globals.css        Tokens, tema claro/oscuro, glass, animaciones
public/                       manifest.json, sw.js, icon.svg (PWA)
android-template/             Proyecto Android WebView wrapper (Gradle + Kotlin)
scripts/configure-android.mjs Inyecta config del build en la plantilla
scripts/setup-android.sh      Instala JDK17 + Android SDK + Gradle (idempotente, ~/.nexa)
.github/workflows/build-apk.yml  Compilación real en GitHub Actions (driver BUILD_DRIVER=github)
CONTRACT.md                   Contrato congelado API ↔ frontend
```

## 7. Funcionalidades verificadas

- Registro / login (email+contraseña con bcrypt + Google opcional), sesión JWT, rutas protegidas, historial aislado por usuario.
- Crear APK desde **URL** (se normaliza `https://` automáticamente; el código que empieza por `<` se rechaza con mensaje claro), **HTML pegado**, **archivo HTML** y **ZIP** (≤50 MB, debe contener `index.html`).
- Icono personalizado, `packageName`, versión, permisos Android seleccionables (INTERNET obligatorio).
- Estados reales persistidos en BD: `En espera / Preparando / Compilando / Completado / Error` con línea de tiempo de eventos y mensaje de error.
- Dashboard con contadores **reales** (totales / completadas / pendientes) y actividad reciente desde la BD.
- Configuración: tema claro/oscuro, color de acento, nombre de usuario, notificaciones, sonidos (sintetizados con Web Audio, sin archivos), cierre de sesión — todo persistido.
- PWA instalable; sidebar en escritorio + barra inferior en móvil; sin modales de términos forzosos.

## 8. Seguridad

- Validación con `zod` en todas las entradas; errores en español sin stack traces.
- Contraseñas con `bcryptjs`; sesiones JWT firmadas con `NEXTAUTH_SECRET`.
- Los callbacks del runner (`/source`, `/status`, `/apk`) se autentican con un token por build; el resto de `/api/*` requiere sesión. Un usuario nunca puede ver/descargar builds de otro.
- Límites de tamaño de subida (`MAX_UPLOAD_MB`); los secretos solo viven en variables de entorno, nunca en el cliente.
- Cabeceras de seguridad (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`).
