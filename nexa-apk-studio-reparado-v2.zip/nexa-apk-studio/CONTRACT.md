# NEXA APK STUDIO — Contrato congelado (Backend ↔ Frontend)

No modificar estos puntos sin acuerdo. Raíz del proyecto: `nexa-apk-studio/`.
Stack: Next.js 14 App Router + TypeScript + Prisma (SQLite por defecto) + NextAuth v4.
Interfaz en español. Iconos con `lucide-react` (nunca emoji en la UI).

## 1. Tokens de diseño (CSS variables en `src/styles/globals.css`)

Nota de almacenamiento: SQLite no soporta enums ni Json; `User.preferences` y `Build.permissions` son columnas String con JSON serializado — parsear con `JSON.parse` al leer y `JSON.stringify` al escribir. Los DTOs de API devuelven objetos ya parseados.

- `--bg`: `#07070d`; `--bg-2`: `#0d0d1a`; `--surface`: `rgba(255,255,255,0.04)`; `--border`: `rgba(255,255,255,0.08)`. `#07070d`; `--bg-2`: `#0d0d1a`; `--surface`: `rgba(255,255,255,0.04)`; `--border`: `rgba(255,255,255,0.08)`.
- `--accent`: `#8b5cf6` (morado); `--accent-2`: `#3b82f6` (azul); gradiente principal: `linear-gradient(135deg,#8b5cf6,#3b82f6,#06b6d4)`.
- `--text`: `#e8e8f0`; `--text-dim`: `#9a9ab0`.
- Radio: `16px` tarjetas, `12px` botones. Sidebar ancho `260px`. Bottom-nav alto `64px`.
- Glassmorphism moderado: `backdrop-filter: blur(14px)` + `border: 1px solid var(--border)` + `background: var(--surface)`.
- Tipografía: `Space Grotesk` (títulos) + `Inter` (texto) vía `next/font/google`.
- Tema claro: variables invertidas (fondo `#f6f6fb`, texto `#14141f`), mismo acento.
- Animaciones: fade/slide de entrada con `@keyframes` + `prefers-reduced-motion` respetado.

## 2. Rutas de páginas (App Router) — propiedad del Frontend

- `/` → pantalla de bienvenida (pública). Hero con gradiente animado, logo NEXA, claim "Convierte tus ideas en aplicaciones Android", botón "Comenzar ahora" → `/login` o `/app` si hay sesión. Sin modales de términos.
- `/login`, `/register` → auth (email/contraseña + Google).
- `/app` → dashboard (protegida).
- `/app/crear` → formulario Crear APK (protegida).
- `/app/historial` → lista de builds (protegida).
- `/app/historial/[id]` → detalle + eventos + descarga (protegida).
- `/app/configuracion` → ajustes (protegida).
- `/app/cuenta` → datos de cuenta (protegida).
- `/app/ayuda` → FAQ + estado del pipeline (protegida).
- Layout `(app)`: sidebar en `md+`, bottom-nav en móvil. Secciones: Inicio, Crear APK, Historial, Configuración, Mi cuenta, Ayuda (iconos lucide: Home, PackagePlus/Hammer, History, Settings, User, HelpCircle).

## 3. Contrato de API (JSON; todas bajo `/api`) — propiedad del Backend

Autenticación: NextAuth v4. Rutas `/api/auth/*` (Google + Credentials). Rutas de app requieren sesión; si no, `401 {error:"unauthorized"}`.

### POST /api/auth/register
Body: `{email, name, password}`. Valida email, password ≥8. Crea user (bcrypt). 201 `{ok:true}`; 409 si email existe.

### GET /api/user → `{id, email, name, image, preferences}`
### PATCH /api/user → body parcial `{name?, preferences?}`. preferences se mergea con la existente. Retorna usuario actualizado.

### GET /api/builds → `{builds: BuildDTO[]}` (del usuario, -createdAt).
### GET /api/builds/stats → `DashboardStatsDTO` (contadores reales de BD).
### GET /api/builds/[id] → `BuildDetailDTO` (404 si no existe / no es del usuario).
### GET /api/builds/[id]/download → APK binario (solo si status=COMPLETED y pertenece al usuario; 404/409 en otro caso).
### GET /api/builds/[id]/source?token=... → descarga del fuente zip para el runner de GitHub (valida `token` == build.callbackToken; sin sesión).

### POST /api/builds (multipart/form-data)
Campos: `appName`, `packageName`, `versionName` (opc, def 1.0.0), `versionCode` (opc, def 1), `contentType` (URL|HTML_PASTE|HTML_FILE|ZIP), `url` (si contentType=URL), `html` (si HTML_PASTE), `permissions` (JSON string array), file `source` (si HTML_FILE o ZIP), file `icon` (opc, png/jpg ≤2MB).
- Normaliza URL: si empieza por `http://` o `https://` se usa tal cual; si no, se prefija `https://`. Si el contenido empieza por `<` o `<!DOCTYPE` no se trata como URL.
- Límites: ZIP/HTML ≤ `MAX_UPLOAD_MB` (def 50MB); icono ≤2MB.
- Almacena fuente como zip en storage; crea Build status=QUEUED + evento; dispara workflow de GitHub Actions (si está configurado). Si `GITHUB_TOKEN`/`GITHUB_REPOSITORY` no están configurados → el build se crea en QUEUED y se devuelve `201 {build, pipelineConfigured:false, message:"...instrucciones..."}`; NUNCA marcar como completado ni inventar APK.
- 201 `{build: BuildDTO, pipelineConfigured: boolean}`. 400 con `{error, details?}` en validación.

### POST /api/builds/[id]/cancel → cambia a ERROR con mensaje "Cancelado por el usuario" (si está en estados activos).

### POST /api/builds/[id]/status?token=...  (callback del runner; valida token)
Body: `{status: "PREPARING"|"BUILDING"|"COMPLETED"|"ERROR", message?, error?}`. Actualiza build + crea evento.
### POST /api/builds/[id]/apk?token=...  (callback del runner; APK en multipart field `apk`)
Guarda APK en storage, status=COMPLETED, apkSize, evento.

### GET /api/pipeline/status → `{configured: boolean, repository?: string}` (público, para la página de Ayuda).

## 4. Pipeline de compilación (Backend + android-template + .github)
- `android-template/`: proyecto Android WebView wrapper (Kotlin, Gradle, minSdk 24, targetSdk 34). `assets/www/` recibe el contenido web. `MainActivity.kt` configura WebView (JS, DOM storage, file access, geolocalización, manejo de permisos en runtime). `AndroidManifest.xml` con INTERNET siempre + permisos seleccionados. `build.gradle` parametriza applicationId, versionName, versionCode, appName, icono.
- Script `scripts/configure-android.mjs` (o Node en el workflow): inyecta appName/package/version/permisos y descomprime el fuente en `assets/www`, convierte icono subido a mipmap.
- `.github/workflows/build-apk.yml`: runs-on ubuntu-latest; setup JDK 17; setup Android SDK (android-34, build-tools 34.0.0, cache); descarga fuente de `${PUBLIC_BASE_URL}/api/builds/${id}/source?token=...`; ejecuta configuración; `./gradlew assembleDebug` (APK debug firmado, instalable); reporta estado vía POST a `/api/builds/${id}/status`; sube APK vía POST a `/api/builds/${id}/apk`; upload-artifact como respaldo.
- Backend dispara con `POST /repos/{owner}/{repo}/actions/workflows/{id}/dispatches` (inputs: build_id, callback_token, source_url). Guarda `githubRunId` haciendo polling breve de `runs` (mejor esfuerzo; el callback es la fuente de verdad).

## 5. PWA (Frontend)
- `public/manifest.json` (name NEXA APK STUDIO, theme_color #8b5cf6, display standalone, iconos 192/512 generados como SVG→PNG o referenciados; mínimo icono SVG + maskable).
- `public/sw.js`: cache estático, network-first para `/api`, skipWaiting + clients.claim. Registro en componente cliente (solo producción).
- `public/icon.svg` logo NEXA original.

## 6. Sonidos (Frontend)
- Módulo `src/lib/sound.ts` con Web Audio API (osciladores sintetizados, sin archivos): click, success, error, start. Toggle global persistido en preferences.sound.

## 7. Reparto de propiedad (no escribir en archivos del otro)
- **Backend**: `prisma/`, `src/lib/server/` (db, auth, storage, github, build-engine, validators), `src/app/api/**`, `android-template/**`, `.github/**`, `scripts/**`, `src/middleware.ts`.
- **Frontend**: `src/app/(welcome)/**`, `src/app/(app)/**`, `src/components/**`, `src/lib/client/**` (sound, api-client, hooks), `src/styles/**`, `public/**` (manifest, sw.js, iconos).
- Ambos leen `src/lib/types.ts` y este `CONTRACT.md` (solo lectura). Si necesitan un helper compartido pequeño, lo acuerdan vía el organizador.
