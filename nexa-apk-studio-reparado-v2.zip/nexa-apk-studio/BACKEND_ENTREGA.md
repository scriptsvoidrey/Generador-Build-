# NEXA APK STUDIO — Backend + Pipeline APK (entrega Backend)

## Verificación realizada
- `npx tsc --noEmit`: **0 errores en archivos del backend**. El único error del proyecto está en `src/components/Button.tsx` (propiedad del Frontend, ajeno a este alcance).
- Las 12 rutas del contrato existen como `route.ts` (listado abajo).
- Sin TODO/placeholder ni simulación de builds: el build real lo compila GitHub Actions; si las vars no están configuradas el build queda en QUEUED y se devuelve `pipelineConfigured:false` con instrucciones.
- `scripts/configure-android.mjs`: sintaxis OK + smoke test end-to-end de ambas variantes (ZIP+icono y URL) ejecutado contra una copia de `android-template/` (parchea app_name, applicationId, versionCode/Name, permisos, copia www/, escribe nexa_config.json, instala icono PNG y elimina los iconos vectoriales).
- `.github/workflows/build-apk.yml`: YAML válido; todas las actions referenciadas existen (`android-actions/setup-android@v3`, `gradle/actions/setup-gradle@v4`, `actions/setup-java@v4`, `actions/checkout@v4`, `actions/upload-artifact@v4`).
- No se añadió ninguna dependencia (todo lo usado ya estaba en package.json: @prisma/client, adm-zip, bcryptjs, next-auth, zod). `@vercel/blob` es import dinámico opcional con fallback a local.

## Archivos creados (base: nexa-apk-studio/)
### src/lib/server/
- `db.ts` — singleton Prisma
- `auth.ts` — NextAuth options (Credentials + Google condicional), `getCurrentUserId()`
- `storage.ts` — driver local + vercel-blob opcional, límites de tamaño
- `github.ts` — `isPipelineConfigured()`, `triggerDispatch()`, `getLatestRunId()` (mejor esfuerzo)
- `build-engine.ts` — `normalizeUrl()`, `packageSource()` (zip normalizado con build_config.json/www/nexa_config/icon), `generateCallbackToken()`
- `validators.ts` — esquemas zod + `parsePermissions()`
- `dto.ts` — `toUserDTO/toBuildDTO/toBuildDetailDTO` (parsea JSON string de preferences/permissions)
- `build-access.ts` — `getOwnBuild()`, `getBuildByCallbackToken()` (comparación tiempo-constante)
- `http.ts` — helpers de respuestas JSON de error (español, sin stack traces)

### Tipos y middleware
- `src/types/next-auth.d.ts` — aumenta session/jwt con userId
- `src/middleware.ts` — protege /app/* (redirect a /login) y /api/* (401); exime /api/auth/*, /api/pipeline/status y callbacks del runner (token query param)
- `next-env.d.ts` — (faltaba, generado)

### API routes (src/app/api/)
- `auth/[...nextauth]/route.ts`
- `auth/register/route.ts` (POST, 201/409)
- `user/route.ts` (GET, PATCH con merge de preferences)
- `builds/route.ts` (GET lista, POST multipart crea build+zip+dispatch)
- `builds/stats/route.ts` (contadores reales de BD + recent 5)
- `builds/[id]/route.ts` (GET detalle con eventos)
- `builds/[id]/download/route.ts` (stream APK, solo COMPLETED+dueño)
- `builds/[id]/source/route.ts` (GET zip fuente, auth por callbackToken)
- `builds/[id]/status/route.ts` (POST callback runner)
- `builds/[id]/apk/route.ts` (POST multipart apk, guarda y marca COMPLETED)
- `builds/[id]/cancel/route.ts` (POST → ERROR "Cancelado por el usuario")
- `pipeline/status/route.ts` (público)

### android-template/ (proyecto Gradle completo, sin wrapper jar)
- `settings.gradle`, `build.gradle` (root), `gradle.properties`
- `app/build.gradle` (compileSdk 34, minSdk 24, targetSdk 34, debug firmado)
- `app/src/main/AndroidManifest.xml` (INTERNET+cleartext+hardwareAccelerated, placeholder de permisos)
- `app/src/main/java/com/nexastudio/webview/MainActivity.kt` (WebView JS/DOM/file, WebChromeClient con onPermissionRequest runtime para cámara/mic/geolocalización, carga startUrl desde assets/nexa_config.json o www/index.html, back button, file chooser)
- `res/values/{strings,colors,themes}.xml`, iconos adaptativos + fallback vectorial, `assets/www/index.html` por defecto

### Pipeline
- `scripts/configure-android.mjs` (Node + adm-zip; parchea nombre/paquete/versión/permisos, descomprime www, instala icono, escribe nexa_config.json)
- `.github/workflows/build-apk.yml` (workflow_dispatch inputs build_id/callback_token/source_url; JDK17, Gradle 8.7, Android SDK android-34+build-tools 34.0.0; reporta PREPARING→BUILDING→(ERROR con log truncado 2KB | COMPLETED); sube APK por multipart + upload-artifact de respaldo)

## Lo que falta para compilar APKs reales
1. **Repo builder en GitHub** que contenga `android-template/`, `scripts/configure-android.mjs` y `.github/workflows/build-apk.yml` (hacer push de estas carpetas a un repo, ej. `tu-usuario/nexa-apk-builder`).
2. **Vars de entorno del backend**: `GITHUB_TOKEN` (PAT con scopes `repo`+`workflow`), `GITHUB_REPOSITORY=owner/repo`, `GITHUB_WORKFLOW_ID=build-apk.yml`, `GITHUB_DEFAULT_BRANCH=main`.
3. En el repo builder: **Settings → Secrets and variables → Actions → Variables**: crear `PUBLIC_BASE_URL` con la URL pública del backend (ej. `https://nexa-tu-app.vercel.app`). **Debe ser alcanzable desde internet** (localhost no funciona; usar deploy Vercel o ngrok en local).
4. `NEXTAUTH_SECRET` con valor aleatorio real.
5. (Opcional) `GOOGLE_CLIENT_ID/SECRET` para login con Google.
6. (Producción en Vercel) cambiar `STORAGE_DRIVER=vercel-blob` + `BLOB_READ_WRITE_TOKEN` e instalar `@vercel/blob`; el storage local es efímero en serverless y el runner de GitHub no podrá descargar el fuente. Con SQLite también se recomienda migrar a Postgres.
