# Despliegue en Vercel — Guía paso a paso

## ⚡ Despliegue rápido (cero configuración)

Esta versión ya funciona en Vercel **sin tocar nada**: súbela y entra con
**"Probar como invitado"** o regístrate con email y contraseña. No necesitas
base de datos ni variables de entorno: usa un "modo demo" en memoria.

- Lo que funciona sin configurar: invitado, registro, login, crear builds, historial.
- Limitación del modo demo: los datos se borran cuando Vercel reinicia la función
  (cold start). Para que tus cuentas y builds persistan, haz los pasos 1-3 de abajo
  (añadir `DATABASE_URL` de Postgres). Google requiere el paso 4.

---

## 1. Crea una base de datos PostgreSQL (solo si quieres datos persistentes)

SQLite usa archivos locales; el filesystem de Vercel es efímero y de solo lectura, así que
registro, login e invitado fallan con error 500. Necesitas una BD externa.

Opción recomendada (gratis): **Neon** — https://neon.tech
1. Regístrate → Create a project → región más cercana (ej. `AWS us-east-1`).
2. Copia la cadena de conexión (aparece como "Connection string / pooled").
   Se parece a: `postgresql://usuario:password@ep-xxxx.us-east-1.aws.neon.tech/neondb?sslmode=require`
3. Guárdala: la pegarás en `DATABASE_URL`.

Alternativas: Vercel Postgres (Storage → Create → Postgres) o Supabase.

## 2. Crea las tablas en la BD (una sola vez)

En tu máquina local, dentro del proyecto:

```bash
# Instala dependencias si no lo hiciste
npm install

# Crea las tablas en la BD de producción
DATABASE_URL="pega-tu-url-de-neon-aqui" npx prisma db push
```

Verás "Your database is now in sync". Esto solo hay que hacerlo la primera vez
(y cuando cambies el schema).

## 3. Variables de entorno en Vercel

En el dashboard de Vercel → tu proyecto → **Settings → Environment Variables**.
Añade estas (marca "Production", "Preview" y "Development"):

| Variable | Valor | ¿Obligatoria? |
|---|---|---|
| `DATABASE_URL` | La URL de Neon (con `?sslmode=require`) | ✅ Sin ella nada funciona |
| `NEXTAUTH_SECRET` | Genera con `openssl rand -base64 32` | ✅ Sin ella hay bucle de login |
| `NEXTAUTH_URL` | `https://tu-proyecto.vercel.app` (o tu dominio) | ⚠️ Recomendada |
| `GOOGLE_CLIENT_ID` | De Google Cloud Console (paso 4) | ❌ Opcional (sin ella, el botón muestra aviso) |
| `GOOGLE_CLIENT_SECRET` | De Google Cloud Console | ❌ Opcional |
| `BUILD_DRIVER` | `github` (en Vercel no hay Android SDK) | ⚠️ Para compilar APKs |
| `GITHUB_TOKEN` | PAT con permisos repo + workflow | Si BUILD_DRIVER=github |
| `GITHUB_REPOSITORY` | `tu-usuario/nexa-apk-builder` | Si BUILD_DRIVER=github |
| `BUILD_CALLBACK_SECRET` | `openssl rand -hex 32` | Si BUILD_DRIVER=github |
| `PUBLIC_BASE_URL` | `https://tu-proyecto.vercel.app` | Si BUILD_DRIVER=github |
| `STORAGE_DRIVER` | `vercel-blob` (local no persiste en Vercel) | ⚠️ Recomendado |
| `BLOB_READ_WRITE_TOKEN` | De Vercel Storage → Blob | Si STORAGE_DRIVER=vercel-blob |

> **Importante**: tras añadir variables, haz **Redeploy** (Deployments → ⋯ → Redeploy)
> para que se apliquen.

## 4. Configurar Google OAuth (opcional, para "Continuar con Google")

1. Ve a https://console.cloud.google.com/ → crea un proyecto.
2. APIs y servicios → Pantalla de consentimiento → External → completa el formulario.
3. Credenciales → Crear credenciales → ID de cliente OAuth → Tipo: Aplicación web.
4. En **URI de redireccionamiento autorizados** añade EXACTAMENTE:
   ```
   https://tu-proyecto.vercel.app/api/auth/callback/google
   ```
   (y `http://localhost:3000/api/auth/callback/google` para probar en local).
5. Copia el ID de cliente y el secreto a las variables de entorno de Vercel.

Si no configuras esto, el botón "Continuar con Google" mostrará un aviso amable
y podrás usar **email+contraseña** o **Entrar como invitado**.

## 5. Build y despliegue

El `package.json` ya trae `"build": "prisma generate && next build"`, que Vercel
detecta automáticamente. No necesitas `vercel.json`.

Sube el código a GitHub/GitLab y "Import Project" en Vercel, o usa la CLI:

```bash
npm i -g vercel
vercel        # despliegue de preview
vercel --prod # producción
```

## 6. Verifica que funciona

1. Abre `/` → "Probar como invitado" → debe entrar al dashboard sin errores.
2. Abre `/register` → crea una cuenta → debe redirigir a `/app`.
3. Abre `/login` → entra con esa cuenta.
4. Si algo falla: en Vercel → Deployments → el despliegue → **Logs** (Runtime)
   para ver el error real. El 99% de las veces es `DATABASE_URL` mal copiada
   (falta `?sslmode=require`) o `NEXTAUTH_SECRET` sin definir.

---

### Modo invitado (nuevo)

- Botón **"Entrar como invitado"** en `/login` y **"Probar como invitado"** en la portada.
- Crea una cuenta aislada por sesión (email `invitado+<id>@nexa.invalid`), sin contraseña.
- Ideal para probar la app sin registrarse ni configurar Google.
